[CmdletBinding()]
param(
    [string]$InstallRoot = (Join-Path $env:LOCALAPPDATA 'D-CATS\FinishedLabelAgent'),
    [long]$RecoverClaimedJobId = 0,
    [long]$RetryFailedJobId = 0
)

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
Add-Type -AssemblyName System.Security

$configPath = Join-Path $InstallRoot 'config.json'
$authPath = Join-Path $InstallRoot 'auth.dpapi'
$logPath = Join-Path $InstallRoot 'agent.log'
$entropy = [Text.Encoding]::UTF8.GetBytes('D-CATS Finished Label Agent v1')
$script:AccessToken = $null
$script:AccessTokenValidUntil = [DateTimeOffset]::MinValue

function Write-AgentLog {
    param([string]$Level, [string]$Message)

    if (Test-Path -LiteralPath $logPath) {
        $length = (Get-Item -LiteralPath $logPath).Length
        if ($length -gt 2097152) {
            $previousLog = Join-Path $InstallRoot 'agent.previous.log'
            Move-Item -LiteralPath $logPath -Destination $previousLog -Force
        }
    }

    $safeMessage = ($Message -replace '[\r\n]+', ' ').Trim()
    $line = '{0} [{1}] {2}{3}' -f ([DateTimeOffset]::Now.ToString('o')), $Level.ToUpperInvariant(), $safeMessage, [Environment]::NewLine
    [IO.File]::AppendAllText($logPath, $line, [Text.UTF8Encoding]::new($false))
}

function Read-ProtectedRefreshToken {
    if (-not (Test-Path -LiteralPath $authPath)) {
        throw 'Encrypted D-CATS authentication is not configured.'
    }

    $protectedBytes = [IO.File]::ReadAllBytes($authPath)
    $plainBytes = [Security.Cryptography.ProtectedData]::Unprotect(
        $protectedBytes,
        $entropy,
        [Security.Cryptography.DataProtectionScope]::CurrentUser
    )
    try {
        return [Text.Encoding]::UTF8.GetString($plainBytes)
    } finally {
        [Array]::Clear($plainBytes, 0, $plainBytes.Length)
    }
}

function Write-ProtectedRefreshToken {
    param([Parameter(Mandatory = $true)][string]$RefreshToken)

    $plainBytes = [Text.Encoding]::UTF8.GetBytes($RefreshToken)
    try {
        $protectedBytes = [Security.Cryptography.ProtectedData]::Protect(
            $plainBytes,
            $entropy,
            [Security.Cryptography.DataProtectionScope]::CurrentUser
        )
        $temporaryPath = $authPath + '.new'
        [IO.File]::WriteAllBytes($temporaryPath, $protectedBytes)
        Move-Item -LiteralPath $temporaryPath -Destination $authPath -Force
    } finally {
        [Array]::Clear($plainBytes, 0, $plainBytes.Length)
    }
}

function Get-HttpStatusCode {
    param([Management.Automation.ErrorRecord]$ErrorRecord)

    try {
        if ($ErrorRecord.Exception.Response -and $ErrorRecord.Exception.Response.StatusCode) {
            return [int]$ErrorRecord.Exception.Response.StatusCode
        }
    } catch {}
    return 0
}

function Refresh-AgentSession {
    param([pscustomobject]$Config)

    $refreshToken = Read-ProtectedRefreshToken
    try {
        $requestBody = @{ refresh_token = $refreshToken } | ConvertTo-Json -Compress
        $headers = @{ apikey = [string]$Config.supabasePublishableKey }
        $response = Invoke-RestMethod `
            -Method Post `
            -Uri ($Config.supabaseUrl.TrimEnd('/') + '/auth/v1/token?grant_type=refresh_token') `
            -Headers $headers `
            -ContentType 'application/json' `
            -Body $requestBody `
            -TimeoutSec 20 `
            -DisableKeepAlive `
            -UseBasicParsing
    } finally {
        $refreshToken = $null
        $requestBody = $null
    }

    if (-not $response.access_token -or -not $response.refresh_token) {
        throw 'Supabase did not return a complete refreshed session.'
    }

    Write-ProtectedRefreshToken -RefreshToken ([string]$response.refresh_token)
    $script:AccessToken = [string]$response.access_token
    $lifetimeSeconds = [Math]::Max(120, [int]$response.expires_in)
    $script:AccessTokenValidUntil = [DateTimeOffset]::UtcNow.AddSeconds($lifetimeSeconds - 90)
    Write-AgentLog 'info' 'D-CATS session refreshed.'
    return $script:AccessToken
}

function Get-AgentAccessToken {
    param([pscustomobject]$Config, [switch]$ForceRefresh)

    if ($ForceRefresh -or -not $script:AccessToken -or [DateTimeOffset]::UtcNow -ge $script:AccessTokenValidUntil) {
        return Refresh-AgentSession -Config $Config
    }
    return $script:AccessToken
}

function Invoke-AgentRpc {
    param(
        [Parameter(Mandatory = $true)][pscustomobject]$Config,
        [Parameter(Mandatory = $true)][string]$Name,
        [Parameter(Mandatory = $true)][hashtable]$Body
    )

    for ($attempt = 0; $attempt -lt 2; $attempt += 1) {
        $token = Get-AgentAccessToken -Config $Config -ForceRefresh:($attempt -eq 1)
        $headers = @{
            apikey = [string]$Config.supabasePublishableKey
            Authorization = 'Bearer ' + $token
        }
        try {
            return Invoke-RestMethod `
                -Method Post `
                -Uri ($Config.supabaseUrl.TrimEnd('/') + '/rest/v1/rpc/' + $Name) `
                -Headers $headers `
                -ContentType 'application/json' `
                -Body ($Body | ConvertTo-Json -Depth 8 -Compress) `
                -TimeoutSec 20 `
                -DisableKeepAlive `
                -UseBasicParsing
        } catch {
            if ($attempt -eq 0 -and (Get-HttpStatusCode -ErrorRecord $_) -eq 401) {
                continue
            }
            throw
        }
    }
}

function ConvertTo-LabelAscii {
    param(
        [AllowNull()][object]$Value,
        [Parameter(Mandatory = $true)][string]$FieldName,
        [int]$MaximumLength = 32
    )

    $text = ([string]$Value).Trim().ToUpperInvariant()
    if (-not $text -or $text.Length -gt $MaximumLength -or $text -notmatch '^[A-Z0-9][A-Z0-9-]*$') {
        throw ('Invalid {0} for direct label printing.' -f $FieldName)
    }
    return $text
}

function ConvertTo-BoxDetailAscii {
    param(
        [AllowNull()][object]$Value,
        [int]$MaximumLength = 38
    )

    $text = ([string]$Value).Trim().ToUpperInvariant()
    $text = ($text -replace '[^A-Z0-9 ./+_-]+', ' ' -replace '\s+', ' ').Trim()
    if (-not $text) { return '-' }
    if ($text.Length -gt $MaximumLength) { return $text.Substring(0, $MaximumLength) }
    return $text
}

function Get-AgentPrinters {
    param([Parameter(Mandatory = $true)][pscustomobject]$Config)

    $configured = @()
    if ($Config.printers) {
        $configured = @($Config.printers)
    } elseif ($Config.printerCode) {
        $legacyTarget = if ([string]$Config.printerCode -match '80X60$') { 'box' } else { 'finished_product' }
        $configured = @([pscustomobject]@{
            printerCode = [string]$Config.printerCode
            siteCode = 'JP'
            labelTarget = $legacyTarget
            labelFormat = if ($legacyTarget -eq 'box') { '80x60' } else { '45x20' }
            printerName = [string]$Config.printerName
            printerAddress = [string]$Config.printerAddress
            printerPort = [int]$Config.printerPort
            enabled = $true
        })
    }

    $result = New-Object Collections.Generic.List[object]
    foreach ($printer in $configured) {
        if ($null -ne $printer.enabled -and -not [bool]$printer.enabled) { continue }
        $code = ([string]$printer.printerCode).Trim().ToUpperInvariant()
        $target = ([string]$printer.labelTarget).Trim().ToLowerInvariant()
        $format = ([string]$printer.labelFormat).Trim()
        if ($code -notmatch '^[A-Z0-9][A-Z0-9_-]{0,63}$') { throw 'A configured printer code is invalid.' }
        if ($target -notin @('finished_product', 'box')) { throw ('Printer {0} has an invalid label target.' -f $code) }
        if (($target -eq 'finished_product' -and $format -ne '45x20') -or ($target -eq 'box' -and $format -ne '80x60')) {
            throw ('Printer {0} has an incompatible label format.' -f $code)
        }
        if (-not [string]$printer.printerAddress -or [int]$printer.printerPort -lt 1) {
            throw ('Printer {0} has no usable network endpoint.' -f $code)
        }
        $result.Add([pscustomobject]@{
            printerCode = $code
            siteCode = ([string]$printer.siteCode).Trim().ToUpperInvariant()
            labelTarget = $target
            labelFormat = $format
            printerName = [string]$printer.printerName
            printerAddress = [string]$printer.printerAddress
            printerPort = [int]$printer.printerPort
        })
    }
    if ($result.Count -eq 0) { throw 'No enabled printers are configured.' }
    if (@($result | Group-Object printerCode | Where-Object Count -gt 1).Count -gt 0) {
        throw 'Printer codes must be unique in the agent configuration.'
    }
    return $result | ForEach-Object { $_ }
}

function Get-FinishedLabelZpl {
    param([Parameter(Mandatory = $true)][pscustomobject]$Payload)

    if ([string]$Payload.job.label_target -ne 'finished_product' -or [string]$Payload.job.label_format -ne '45x20') {
        throw 'The background agent only accepts finished-product 45x20 jobs.'
    }

    $units = @($Payload.units)
    if ($units.Count -eq 0) {
        throw 'The print job contains no finished-product units.'
    }

    $labels = New-Object Collections.Generic.List[string]
    foreach ($unit in $units) {
        $serial = ConvertTo-LabelAscii -Value $unit.manufacturing_serial -FieldName 'manufacturing serial' -MaximumLength 24
        $productCandidate = $unit.gltek_part_number
        if (-not $productCandidate) { $productCandidate = $unit.product_no }
        if (-not $productCandidate) { $productCandidate = $Payload.issue.product_no }
        if (-not $productCandidate) { $productCandidate = $Payload.issue.manufacturer_part_number }
        if (-not $productCandidate) { $productCandidate = $Payload.issue.genuine_part_number }
        $productNumber = ConvertTo-LabelAscii -Value $productCandidate -FieldName 'GLTEK part number' -MaximumLength 24

        $label = @"
^XA
^CI28
^MNY
^MTT
^PW360
^LL160
^LH0,20
^LT0
^LS0
^FO14,4^A0N,22,20^FDGLTEK^FS
^FO266,12^A0N,14,12^FDPRODUCT ID^FS
^FO14,30^GB340,2,2^FS
^FO14,36^BQN,2,4^FDMA,$serial^FS
^FO116,40^A0N,14,12^FDGLTEK PART NO.^FS
^FO116,56^A0N,24,20^FD$productNumber^FS
^FO116,84^GB238,2,2^FS
^FO116,91^A0N,14,12^FDMFG SERIAL / S/N^FS
^FO116,108^A0N,26,19^FD$serial^FS
^PQ1,0,1,N
^XZ
"@
        $labels.Add($label.Trim())
    }

    return ($labels -join [Environment]::NewLine)
}

function Get-BoxLabelZpl {
    param([Parameter(Mandatory = $true)][pscustomobject]$Payload)

    if ([string]$Payload.job.label_target -ne 'box' -or [string]$Payload.job.label_format -ne '80x60') {
        throw 'The background agent only accepts box-label 80x60 jobs in this renderer.'
    }
    $units = @($Payload.units)
    if ($units.Count -eq 0) { throw 'The print job contains no finished-product units.' }

    $labels = New-Object Collections.Generic.List[string]
    foreach ($unit in $units) {
        $serial = ConvertTo-LabelAscii -Value $unit.manufacturing_serial -FieldName 'manufacturing serial' -MaximumLength 24
        $productCandidate = $unit.gltek_part_number
        if (-not $productCandidate) { $productCandidate = $unit.product_no }
        if (-not $productCandidate) { $productCandidate = $Payload.issue.product_no }
        if (-not $productCandidate) { $productCandidate = $Payload.issue.manufacturer_part_number }
        if (-not $productCandidate) { $productCandidate = $Payload.issue.genuine_part_number }
        $productNumber = ConvertTo-LabelAscii -Value $productCandidate -FieldName 'GLTEK part number' -MaximumLength 24
        $manufacturerLine = ConvertTo-BoxDetailAscii -Value ((@($unit.manufacturer, $unit.manufacturer_part_number) | Where-Object { $_ }) -join ' / ')
        $genuineLine = ConvertTo-BoxDetailAscii -Value ((@($unit.genuine_part_number, $Payload.issue.genuine_part_number_2) | Where-Object { $_ }) -join ' / ')
        $specification = ConvertTo-BoxDetailAscii -Value ((@($Payload.issue.nominal_voltage, $Payload.issue.nominal_output, $Payload.issue.nominal_spec) | Where-Object { $_ }) -join ' / ')
        $category = ConvertTo-BoxDetailAscii -Value $Payload.issue.product_category -MaximumLength 18
        $kind = switch (([string]$unit.product_kind).Trim().ToLowerInvariant()) {
            'rebuilt' { 'REBUILT' }
            'new' { 'NEW' }
            default { ConvertTo-BoxDetailAscii -Value $unit.product_kind -MaximumLength 18 }
        }

        $label = @"
^XA
^CI28
^MNY
^MTT
^PW640
^LL480
^LH0,0
^LT0
^LS0
^FO16,10^A0N,34,30^FDGLTEK^FS
^FO475,15^A0N,22,19^FDBOX LABEL^FS
^FO16,48^GB608,2,2^FS
^FO480,55^A0N,18,16^FD$category^FS
^FO18,62^A0N,17,15^FDGLTEK PART NO.^FS
^FO18,82^A0N,38,31^FD$productNumber^FS
^FO18,128^BY2,2,82^BCN,82,N,N,N^FD$productNumber^FS
^FO18,214^A0N,19,17^FD$productNumber^FS
^FO16,240^GB608,2,2^FS
^FO18,252^A0N,15,13^FDMANUFACTURER / MFR PART NO.^FS
^FO18,270^A0N,21,18^FD$manufacturerLine^FS
^FO18,302^A0N,15,13^FDGENUINE PART NO.^FS
^FO18,320^A0N,21,18^FD$genuineLine^FS
^FO18,352^A0N,15,13^FDSPECIFICATION^FS
^FO18,370^A0N,21,18^FD$specification^FS
^FO18,405^A0N,15,13^FDPRODUCT TYPE^FS
^FO18,423^A0N,24,20^FD$kind^FS
^FO452,255^BQN,2,5^FDMA,$serial^FS
^FO420,388^A0N,14,12^FDMFG SERIAL / S/N^FS
^FO410,408^A0N,25,20^FD$serial^FS
^PQ1,0,1,N
^XZ
"@
        $labels.Add($label.Trim())
    }
    return ($labels -join [Environment]::NewLine)
}

function Get-LabelZpl {
    param([Parameter(Mandatory = $true)][pscustomobject]$Payload)

    if ([string]$Payload.job.label_target -eq 'box') { return Get-BoxLabelZpl -Payload $Payload }
    return Get-FinishedLabelZpl -Payload $Payload
}

function Test-PrinterConnection {
    param(
        [Parameter(Mandatory = $true)][pscustomobject]$Printer,
        [Parameter(Mandatory = $true)][pscustomobject]$Config
    )

    $client = [Net.Sockets.TcpClient]::new()
    try {
        $connectTask = $client.ConnectAsync([string]$Printer.printerAddress, [int]$Printer.printerPort)
        return $connectTask.Wait([int]$Config.connectTimeoutMs) -and $client.Connected
    } catch {
        return $false
    } finally {
        $client.Dispose()
    }
}

function Send-ZplToPrinter {
    param(
        [Parameter(Mandatory = $true)][pscustomobject]$Config,
        [Parameter(Mandatory = $true)][pscustomobject]$Printer,
        [Parameter(Mandatory = $true)][string]$Zpl
    )

    $bytes = [Text.Encoding]::ASCII.GetBytes($Zpl)
    $client = [Net.Sockets.TcpClient]::new()
    $stream = $null
    try {
        $client.NoDelay = $true
        $client.SendTimeout = [int]$Config.sendTimeoutMs
        $connectTask = $client.ConnectAsync([string]$Printer.printerAddress, [int]$Printer.printerPort)
        if (-not $connectTask.Wait([int]$Config.connectTimeoutMs) -or -not $client.Connected) {
            throw 'Timed out connecting to the Brother label printer.'
        }
        $stream = $client.GetStream()
        $stream.WriteTimeout = [int]$Config.sendTimeoutMs
        $stream.Write($bytes, 0, $bytes.Length)
        $stream.Flush()
    } finally {
        if ($stream) { $stream.Dispose() }
        $client.Dispose()
        [Array]::Clear($bytes, 0, $bytes.Length)
    }
}

if (-not (Test-Path -LiteralPath $InstallRoot)) {
    throw 'The D-CATS finished-label agent is not installed.'
}
if (-not (Test-Path -LiteralPath $configPath)) {
    throw 'The D-CATS finished-label agent configuration is missing.'
}

$config = [IO.File]::ReadAllText($configPath, [Text.Encoding]::UTF8) | ConvertFrom-Json
if ([string]$config.supabaseProjectRef -ne 'jqoeqximtwfpqwzngutj') {
    throw 'Unexpected Supabase project reference.'
}
$printers = @(Get-AgentPrinters -Config $config)

$sid = [Security.Principal.WindowsIdentity]::GetCurrent().User.Value -replace '[^A-Za-z0-9]', '_'
$mutex = [Threading.Mutex]::new($false, 'Local\DcatsFinishedLabelAgent_' + $sid)
$ownsMutex = $false
try {
    $ownsMutex = $mutex.WaitOne(0)
    if (-not $ownsMutex) { exit 0 }

    Write-AgentLog 'info' ('Agent started for {0} configured printer(s).' -f $printers.Count)
    try {
        [void](Get-AgentAccessToken -Config $config -ForceRefresh)
    } catch {
        Write-AgentLog 'error' 'D-CATS authentication expired. Run D-CATS printer setup again.'
        throw
    }

    if ($RecoverClaimedJobId -gt 0) {
        [void](Invoke-AgentRpc `
            -Config $config `
            -Name 'finish_finished_label_print_job' `
            -Body @{
                target_job_id = $RecoverClaimedJobId
                target_success = $false
                target_error_message = 'Background agent recovery after an interrupted print attempt'
            })
        Write-AgentLog 'info' ('Recovered claimed job {0} as an error.' -f $RecoverClaimedJobId)
        exit 0
    }

    if ($RetryFailedJobId -gt 0) {
        [void](Invoke-AgentRpc `
            -Config $config `
            -Name 'retry_finished_label_print_job' `
            -Body @{ target_job_id = $RetryFailedJobId })
        Write-AgentLog 'info' ('Requeued failed job {0}.' -f $RetryFailedJobId)
        exit 0
    }

    $heartbeatDue = @{}
    while ($true) {
        foreach ($printer in $printers) {
            $claimedPayload = $null
            try {
                $printerCode = [string]$printer.printerCode
                $now = [DateTimeOffset]::UtcNow
                if (-not $heartbeatDue.ContainsKey($printerCode) -or $now -ge $heartbeatDue[$printerCode]) {
                    $ready = Test-PrinterConnection -Printer $printer -Config $config
                    [void](Invoke-AgentRpc `
                        -Config $config `
                        -Name 'heartbeat_finished_label_print_station' `
                        -Body @{
                            target_printer_code = $printerCode
                            target_ready = $ready
                            target_error = if ($ready) { $null } else { 'Printer connection failed' }
                        })
                    $heartbeatDue[$printerCode] = $now.AddSeconds(30)
                    if (-not $ready) {
                        Write-AgentLog 'error' ('Printer {0} is not reachable.' -f $printerCode)
                        continue
                    }
                }

                $claimedPayload = Invoke-AgentRpc `
                    -Config $config `
                    -Name 'claim_finished_label_print_job' `
                    -Body @{ target_printer_code = $printerCode }

            $emptyPayloadText = if ($claimedPayload -is [string]) { $claimedPayload.Trim() } else { $null }
            if ($null -eq $claimedPayload -or $emptyPayloadText -eq '' -or $emptyPayloadText -eq 'null') {
                continue
            }
            if (-not $claimedPayload.job -or -not $claimedPayload.job.id) {
                throw 'The print queue returned an invalid non-empty payload.'
            }

            $jobId = [long]$claimedPayload.job.id
            Write-AgentLog 'info' ('Job {0} claimed.' -f $jobId)
            $zpl = Get-LabelZpl -Payload $claimedPayload
            Write-AgentLog 'info' ('Job {0} ZPL generated.' -f $jobId)
            Send-ZplToPrinter -Config $config -Printer $printer -Zpl $zpl
            Write-AgentLog 'info' ('Job {0} ZPL sent; reporting completion.' -f $jobId)
            [void](Invoke-AgentRpc `
                -Config $config `
                -Name 'finish_finished_label_print_job' `
                -Body @{
                    target_job_id = $jobId
                    target_success = $true
                    target_error_message = $null
                })
            Write-AgentLog 'info' ('Job {0} sent to printer {1}.' -f $jobId, $printerCode)
            } catch {
                $message = $_.Exception.Message
                Write-AgentLog 'error' $message
                if ($claimedPayload -and $claimedPayload.job -and $claimedPayload.job.id) {
                    try {
                        [void](Invoke-AgentRpc `
                            -Config $config `
                            -Name 'finish_finished_label_print_job' `
                            -Body @{
                                target_job_id = [long]$claimedPayload.job.id
                                target_success = $false
                                target_error_message = $message
                            })
                    } catch {
                        Write-AgentLog 'error' ('Could not report failed job: ' + $_.Exception.Message)
                    }
                }
                $heartbeatDue[[string]$printer.printerCode] = [DateTimeOffset]::MinValue
            }
        }
        Start-Sleep -Seconds ([int]$config.pollSeconds)
    }
} finally {
    if ($ownsMutex) { [void]$mutex.ReleaseMutex() }
    $mutex.Dispose()
    Write-AgentLog 'info' 'Agent stopped.'
}
