[CmdletBinding()]
param(
    [ValidateSet('finished_product', 'box')][string]$LabelTarget = 'finished_product',
    [string]$InstallRoot = (Join-Path $env:LOCALAPPDATA 'D-CATS\FinishedLabelAgent')
)

$ErrorActionPreference = 'Stop'
$taskName = 'D-CATS Finished Label Background Agent'
$configPath = Join-Path $InstallRoot 'config.json'

if (-not (Test-Path -LiteralPath $configPath)) {
    throw 'The D-CATS label-printer configuration is missing. Run setup first.'
}

$config = [IO.File]::ReadAllText($configPath, [Text.Encoding]::UTF8) | ConvertFrom-Json
$printers = @($config.printers | Where-Object {
    ($null -eq $_.enabled -or [bool]$_.enabled) -and [string]$_.labelTarget -eq $LabelTarget
})
if ($printers.Count -ne 1) {
    throw ('Exactly one enabled {0} printer must be configured.' -f $LabelTarget)
}
$printer = $printers[0]

$zpl = if ($LabelTarget -eq 'box') {
    @"
^XA
^PW640
^LL480
^LH0,0
^MNY
^MTT
^FO24,24^GB592,432,3^FS
^FO52,54^A0N,46,40^FDD-CATS BOX LABEL^FS
^FO52,118^A0N,34,28^FD80 x 60 mm / 203 dpi^FS
^FO52,178^A0N,34,28^FDGAP / THERMAL TRANSFER^FS
^FO52,254^GB536,2,2^FS
^FO52,292^A0N,48,42^FDTEST PRINT OK^FS
^FO52,366^A0N,26,22^FDPrinter: $([string]$printer.printerCode)^FS
^PQ1,0,1,N
^XZ
"@
} else {
    @"
^XA
^PW360
^LL160
^LH0,20
^MNY
^MTT
^FO14,8^A0N,24,20^FDD-CATS 45 x 20 mm^FS
^FO14,40^GB332,2,2^FS
^FO14,54^A0N,28,24^FDTEST PRINT OK^FS
^FO14,92^A0N,18,15^FD203 dpi / GAP / TT^FS
^PQ1,0,1,N
^XZ
"@
}

$task = Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue
$restartTask = $task -and [string]$task.State -eq 'Running'
$mutex = $null
$ownsMutex = $false
try {
    if ($restartTask) {
        Stop-ScheduledTask -TaskName $taskName
        for ($attempt = 0; $attempt -lt 40; $attempt += 1) {
            if ([string](Get-ScheduledTask -TaskName $taskName).State -ne 'Running') { break }
            Start-Sleep -Milliseconds 250
        }
    }

    $sid = [Security.Principal.WindowsIdentity]::GetCurrent().User.Value -replace '[^A-Za-z0-9]', '_'
    $mutex = [Threading.Mutex]::new($false, 'Local\DcatsFinishedLabelAgent_' + $sid)
    try {
        $ownsMutex = $mutex.WaitOne(10000)
    } catch [Threading.AbandonedMutexException] {
        $ownsMutex = $true
    }
    if (-not $ownsMutex) {
        throw 'The print agent did not become idle. Wait until the current label finishes and try again.'
    }

    $bytes = [Text.Encoding]::ASCII.GetBytes($zpl)
    $client = [Net.Sockets.TcpClient]::new()
    $stream = $null
    try {
        $client.NoDelay = $true
        $client.SendTimeout = 5000
        $connectTask = $client.ConnectAsync([string]$printer.printerAddress, [int]$printer.printerPort)
        if (-not $connectTask.Wait(5000) -or -not $client.Connected) {
            throw 'Timed out connecting to the Brother label printer.'
        }
        $stream = $client.GetStream()
        $stream.WriteTimeout = 5000
        $stream.Write($bytes, 0, $bytes.Length)
        $stream.Flush()
    } finally {
        if ($stream) { $stream.Dispose() }
        $client.Dispose()
        [Array]::Clear($bytes, 0, $bytes.Length)
    }

    Write-Output ('Sent a {0} test label to {1}.' -f [string]$printer.labelFormat, [string]$printer.printerCode)
} finally {
    if ($ownsMutex) { [void]$mutex.ReleaseMutex() }
    if ($mutex) { $mutex.Dispose() }
    if ($restartTask) { Start-ScheduledTask -TaskName $taskName }
}
