﻿[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$installRoot = Join-Path $env:LOCALAPPDATA 'D-CATS\FinishedLabelAgent'

function Get-NetworkPrinterChoices {
    $choices = New-Object Collections.Generic.List[object]
    try {
        foreach ($printer in @(Get-Printer -ErrorAction Stop | Sort-Object Name)) {
            try {
                $port = Get-PrinterPort -Name $printer.PortName -ErrorAction Stop
                $address = ([string]$port.PrinterHostAddress).Trim()
                if (-not $address) { continue }
                $parsedAddress = $null
                if (-not [Net.IPAddress]::TryParse($address, [ref]$parsedAddress)) { continue }
                $choices.Add([pscustomobject]@{
                    Display = ('{0}  /  {1}' -f $printer.Name, $address)
                    Name = [string]$printer.Name
                    Address = $address
                    Kind = 'printer'
                })
            } catch {}
        }
    } catch {}
    return @($choices | ForEach-Object { $_ })
}

function Test-PrinterEndpoint {
    param([Parameter(Mandatory = $true)][string]$Address)

    $parsedAddress = $null
    if (-not [Net.IPAddress]::TryParse($Address, [ref]$parsedAddress)) {
        throw 'IPアドレスを正しく入力してください。'
    }
    $client = [Net.Sockets.TcpClient]::new()
    try {
        $task = $client.ConnectAsync($Address, 9100)
        if (-not $task.Wait(3000) -or -not $client.Connected) {
            throw 'プリンターのTCP 9100番ポートへ接続できません。電源とLAN接続を確認してください。'
        }
    } finally {
        $client.Dispose()
    }
}

function Add-TextLabel {
    param(
        [Windows.Forms.Control]$Parent,
        [string]$Text,
        [int]$X,
        [int]$Y,
        [int]$Width,
        [int]$Height = 24,
        [bool]$Bold = $false
    )

    $label = [Windows.Forms.Label]::new()
    $label.Location = [Drawing.Point]::new($X, $Y)
    $label.Size = [Drawing.Size]::new($Width, $Height)
    $label.Text = $Text
    if ($Bold) { $label.Font = [Drawing.Font]::new('Yu Gothic UI', 10, [Drawing.FontStyle]::Bold) }
    $Parent.Controls.Add($label)
    return $label
}

$printerChoices = @(Get-NetworkPrinterChoices)
$manualFinishedChoice = [pscustomobject]@{
    Display = '一覧にないプリンターをIPアドレスで指定'
    Name = 'Brother TD-4420TN / 45x20'
    Address = ''
    Kind = 'manual'
}
$manualBoxChoice = [pscustomobject]@{
    Display = '一覧にないプリンターをIPアドレスで指定'
    Name = 'Brother TD-4420TN / 80x60'
    Address = ''
    Kind = 'manual'
}
$boxLaterChoice = [pscustomobject]@{
    Display = '後で設定する（箱シールは印刷待ちに送信できません）'
    Name = ''
    Address = ''
    Kind = 'none'
}

$form = [Windows.Forms.Form]::new()
$form.Text = 'D-CATS TD-4420TN 初回設定'
$form.StartPosition = 'CenterScreen'
$form.ClientSize = [Drawing.Size]::new(780, 680)
$form.FormBorderStyle = [Windows.Forms.FormBorderStyle]::FixedDialog
$form.MaximizeBox = $false
$form.MinimizeBox = $false
$form.TopMost = $true
$form.Font = [Drawing.Font]::new('Yu Gothic UI', 10)

$title = Add-TextLabel -Parent $form -Text 'このPCをD-CATS印刷端末として登録' -X 24 -Y 18 -Width 710 -Height 32 -Bold $true
$title.Font = [Drawing.Font]::new('Yu Gothic UI', 16, [Drawing.FontStyle]::Bold)
[void](Add-TextLabel -Parent $form -Text '45×20mmと80×60mmを物理プリンターへ割り当てます。Windowsの既定プリンターは変更しません。' -X 24 -Y 55 -Width 730 -Height 28)

[void](Add-TextLabel -Parent $form -Text '拠点' -X 24 -Y 94 -Width 110 -Bold $true)
$siteBox = [Windows.Forms.ComboBox]::new()
$siteBox.Location = [Drawing.Point]::new(140, 90)
$siteBox.Size = [Drawing.Size]::new(260, 30)
$siteBox.DropDownStyle = [Windows.Forms.ComboBoxStyle]::DropDownList
[void]$siteBox.Items.Add('JP | 日本')
[void]$siteBox.Items.Add('PH | フィリピン')
$siteBox.SelectedIndex = 0
$form.Controls.Add($siteBox)

$finishedGroup = [Windows.Forms.GroupBox]::new()
$finishedGroup.Text = '完品シール（必須）  45 × 20 mm'
$finishedGroup.Location = [Drawing.Point]::new(24, 132)
$finishedGroup.Size = [Drawing.Size]::new(732, 145)
$form.Controls.Add($finishedGroup)
[void](Add-TextLabel -Parent $finishedGroup -Text 'プリンター' -X 16 -Y 31 -Width 105 -Bold $true)
$finishedBox = [Windows.Forms.ComboBox]::new()
$finishedBox.Location = [Drawing.Point]::new(126, 28)
$finishedBox.Size = [Drawing.Size]::new(580, 30)
$finishedBox.DropDownStyle = [Windows.Forms.ComboBoxStyle]::DropDownList
$finishedBox.DisplayMember = 'Display'
foreach ($choice in $printerChoices) { [void]$finishedBox.Items.Add($choice) }
[void]$finishedBox.Items.Add($manualFinishedChoice)
$finishedBox.SelectedIndex = 0
$finishedGroup.Controls.Add($finishedBox)
[void](Add-TextLabel -Parent $finishedGroup -Text 'IPアドレス' -X 16 -Y 72 -Width 105 -Bold $true)
$finishedAddressBox = [Windows.Forms.TextBox]::new()
$finishedAddressBox.Location = [Drawing.Point]::new(126, 69)
$finishedAddressBox.Size = [Drawing.Size]::new(280, 30)
$finishedGroup.Controls.Add($finishedAddressBox)
$finishedReadyCheck = [Windows.Forms.CheckBox]::new()
$finishedReadyCheck.Location = [Drawing.Point]::new(426, 68)
$finishedReadyCheck.Size = [Drawing.Size]::new(280, 46)
$finishedReadyCheck.Text = "用紙・リボンをセット済み`r`n登録後に校正・テスト印刷"
$finishedGroup.Controls.Add($finishedReadyCheck)

$boxGroup = [Windows.Forms.GroupBox]::new()
$boxGroup.Text = '箱シール（後から設定可能）  80 × 60 mm'
$boxGroup.Location = [Drawing.Point]::new(24, 290)
$boxGroup.Size = [Drawing.Size]::new(732, 145)
$form.Controls.Add($boxGroup)
[void](Add-TextLabel -Parent $boxGroup -Text 'プリンター' -X 16 -Y 31 -Width 105 -Bold $true)
$boxBox = [Windows.Forms.ComboBox]::new()
$boxBox.Location = [Drawing.Point]::new(126, 28)
$boxBox.Size = [Drawing.Size]::new(580, 30)
$boxBox.DropDownStyle = [Windows.Forms.ComboBoxStyle]::DropDownList
$boxBox.DisplayMember = 'Display'
[void]$boxBox.Items.Add($boxLaterChoice)
foreach ($choice in $printerChoices) { [void]$boxBox.Items.Add($choice) }
[void]$boxBox.Items.Add($manualBoxChoice)
$boxBox.SelectedIndex = 0
$boxGroup.Controls.Add($boxBox)
[void](Add-TextLabel -Parent $boxGroup -Text 'IPアドレス' -X 16 -Y 72 -Width 105 -Bold $true)
$boxAddressBox = [Windows.Forms.TextBox]::new()
$boxAddressBox.Location = [Drawing.Point]::new(126, 69)
$boxAddressBox.Size = [Drawing.Size]::new(280, 30)
$boxAddressBox.Enabled = $false
$boxGroup.Controls.Add($boxAddressBox)
$boxReadyCheck = [Windows.Forms.CheckBox]::new()
$boxReadyCheck.Location = [Drawing.Point]::new(426, 68)
$boxReadyCheck.Size = [Drawing.Size]::new(280, 46)
$boxReadyCheck.Text = "用紙・リボンをセット済み`r`n登録後に校正・テスト印刷"
$boxReadyCheck.Enabled = $false
$boxGroup.Controls.Add($boxReadyCheck)

[void](Add-TextLabel -Parent $form -Text 'D-CATS認証' -X 24 -Y 456 -Width 125 -Bold $true)
[void](Add-TextLabel -Parent $form -Text 'メールアドレス' -X 24 -Y 492 -Width 125)
$emailBox = [Windows.Forms.TextBox]::new()
$emailBox.Location = [Drawing.Point]::new(155, 488)
$emailBox.Size = [Drawing.Size]::new(280, 30)
$form.Controls.Add($emailBox)
[void](Add-TextLabel -Parent $form -Text 'パスワード' -X 450 -Y 492 -Width 90)
$passwordBox = [Windows.Forms.TextBox]::new()
$passwordBox.Location = [Drawing.Point]::new(545, 488)
$passwordBox.Size = [Drawing.Size]::new(211, 30)
$passwordBox.UseSystemPasswordChar = $true
$form.Controls.Add($passwordBox)
[void](Add-TextLabel -Parent $form -Text 'パスワードは保存しません。更新トークンだけをこのWindowsユーザー用に暗号化して保存します。' -X 155 -Y 523 -Width 600 -Height 27)

$connectionButton = [Windows.Forms.Button]::new()
$connectionButton.Location = [Drawing.Point]::new(24, 570)
$connectionButton.Size = [Drawing.Size]::new(150, 38)
$connectionButton.Text = 'プリンター接続確認'
$form.Controls.Add($connectionButton)
$statusLabel = Add-TextLabel -Parent $form -Text '' -X 190 -Y 578 -Width 330 -Height 28
$statusLabel.ForeColor = [Drawing.Color]::FromArgb(31, 93, 66)

$installButton = [Windows.Forms.Button]::new()
$installButton.Location = [Drawing.Point]::new(525, 563)
$installButton.Size = [Drawing.Size]::new(231, 46)
$installButton.Text = 'このPCを印刷端末として登録'
$installButton.BackColor = [Drawing.Color]::FromArgb(28, 92, 67)
$installButton.ForeColor = [Drawing.Color]::White
$installButton.FlatStyle = [Windows.Forms.FlatStyle]::Flat
$form.Controls.Add($installButton)

$cancelButton = [Windows.Forms.Button]::new()
$cancelButton.Location = [Drawing.Point]::new(651, 625)
$cancelButton.Size = [Drawing.Size]::new(105, 34)
$cancelButton.Text = 'キャンセル'
$cancelButton.DialogResult = [Windows.Forms.DialogResult]::Cancel
$form.Controls.Add($cancelButton)

function Sync-PrinterChoice {
    param(
        [Windows.Forms.ComboBox]$Selector,
        [Windows.Forms.TextBox]$AddressBox,
        [Windows.Forms.CheckBox]$ReadyCheck
    )

    $selected = $Selector.SelectedItem
    $disabled = -not $selected -or [string]$selected.Kind -eq 'none'
    $AddressBox.Enabled = -not $disabled
    $ReadyCheck.Enabled = -not $disabled
    if ($disabled) {
        $AddressBox.Clear()
        $ReadyCheck.Checked = $false
    } elseif ([string]$selected.Kind -eq 'printer') {
        $AddressBox.Text = [string]$selected.Address
    } else {
        $AddressBox.Clear()
        $AddressBox.Focus()
    }
}

function Selected-PrinterName {
    param([Windows.Forms.ComboBox]$Selector, [string]$Fallback)
    $selected = $Selector.SelectedItem
    if ($selected -and [string]$selected.Kind -eq 'printer') { return [string]$selected.Name }
    if ($selected -and [string]$selected.Kind -eq 'none') { return '' }
    return $Fallback
}

$finishedBox.Add_SelectedIndexChanged({ Sync-PrinterChoice -Selector $finishedBox -AddressBox $finishedAddressBox -ReadyCheck $finishedReadyCheck })
$boxBox.Add_SelectedIndexChanged({ Sync-PrinterChoice -Selector $boxBox -AddressBox $boxAddressBox -ReadyCheck $boxReadyCheck })
Sync-PrinterChoice -Selector $finishedBox -AddressBox $finishedAddressBox -ReadyCheck $finishedReadyCheck

$connectionButton.Add_Click({
    try {
        Test-PrinterEndpoint -Address $finishedAddressBox.Text.Trim()
        if ($boxAddressBox.Enabled) { Test-PrinterEndpoint -Address $boxAddressBox.Text.Trim() }
        $statusLabel.Text = '接続できました。登録へ進めます。'
        $statusLabel.ForeColor = [Drawing.Color]::FromArgb(31, 93, 66)
    } catch {
        $statusLabel.Text = $_.Exception.Message
        $statusLabel.ForeColor = [Drawing.Color]::FromArgb(168, 40, 40)
    }
})

$form.AcceptButton = $installButton
$form.CancelButton = $cancelButton
$form.Add_Shown({
    if ($printerChoices.Count -eq 0) {
        $statusLabel.Text = 'Windows登録済みプリンターがないため、IPアドレスを入力してください。'
    }
})

$installButton.Add_Click({
    if ([string]::IsNullOrWhiteSpace($emailBox.Text) -or [string]::IsNullOrWhiteSpace($passwordBox.Text)) {
        [void][Windows.Forms.MessageBox]::Show($form, 'D-CATSのメールアドレスとパスワードを入力してください。', 'D-CATS 初回設定', 'OK', 'Warning')
        return
    }
    if ([string]::IsNullOrWhiteSpace($finishedAddressBox.Text)) {
        [void][Windows.Forms.MessageBox]::Show($form, '完品シール用プリンターのIPアドレスを入力してください。', 'D-CATS 初回設定', 'OK', 'Warning')
        return
    }
    if ($boxAddressBox.Enabled -and [string]::IsNullOrWhiteSpace($boxAddressBox.Text)) {
        [void][Windows.Forms.MessageBox]::Show($form, '箱シール用プリンターのIPアドレスを入力してください。', 'D-CATS 初回設定', 'OK', 'Warning')
        return
    }
    if ($boxAddressBox.Enabled -and $finishedAddressBox.Text.Trim() -eq $boxAddressBox.Text.Trim()) {
        [void][Windows.Forms.MessageBox]::Show($form, '45×20mmと80×60mmは別の物理プリンターを選択してください。', 'D-CATS 初回設定', 'OK', 'Warning')
        return
    }
    $form.DialogResult = [Windows.Forms.DialogResult]::OK
    $form.Close()
})

$dialogResult = $form.ShowDialog()
if ($dialogResult -ne [Windows.Forms.DialogResult]::OK) {
    $form.Dispose()
    exit 1
}

$selectedSite = if ([string]$siteBox.SelectedItem -like 'PH*') { 'PH' } else { 'JP' }
$finishedPrinterName = Selected-PrinterName -Selector $finishedBox -Fallback 'Brother TD-4420TN / 45x20'
$boxPrinterName = Selected-PrinterName -Selector $boxBox -Fallback 'Brother TD-4420TN / 80x60'
$finishedPrinterAddress = $finishedAddressBox.Text.Trim()
$boxPrinterAddress = if ($boxAddressBox.Enabled) { $boxAddressBox.Text.Trim() } else { '' }
$runFinishedMediaSetup = $finishedReadyCheck.Checked
$runBoxMediaSetup = $boxReadyCheck.Checked -and $boxAddressBox.Enabled
$securePassword = ConvertTo-SecureString $passwordBox.Text -AsPlainText -Force
$credential = [Management.Automation.PSCredential]::new($emailBox.Text.Trim(), $securePassword)
$passwordBox.Clear()

try {
    $installer = Join-Path $PSScriptRoot 'Install-DcatsFinishedLabelAgent.ps1'
    $result = & $installer `
        -Email $credential.UserName `
        -Credential $credential `
        -SiteCode $selectedSite `
        -FinishedPrinterName $finishedPrinterName `
        -FinishedPrinterAddress $finishedPrinterAddress `
        -BoxPrinterName $boxPrinterName `
        -BoxPrinterAddress $boxPrinterAddress

    $completed = @('印刷端末の登録が完了しました。', [string]($result | Select-Object -Last 1))
    foreach ($target in @(
        [pscustomobject]@{ Enabled = $runFinishedMediaSetup; Code = 'finished_product'; Name = '完品シール 45×20mm' },
        [pscustomobject]@{ Enabled = $runBoxMediaSetup; Code = 'box'; Name = '箱シール 80×60mm' }
    )) {
        if (-not $target.Enabled) { continue }
        try {
            & (Join-Path $installRoot 'Calibrate-DcatsLabelPrinter.ps1') -LabelTarget $target.Code -ConfirmMediaLoaded | Out-Null
            & (Join-Path $installRoot 'Test-DcatsLabelPrinter.ps1') -LabelTarget $target.Code | Out-Null
            $completed += ($target.Name + ': 校正・テスト印刷 完了')
        } catch {
            $completed += ($target.Name + ': 登録済み / 校正・テスト印刷は要確認 - ' + $_.Exception.Message)
        }
    }
    if (-not $runFinishedMediaSetup) { $completed += '完品シール: 設定ツールから校正・テスト印刷を実行できます。' }
    if ($boxAddressBox.Enabled -and -not $runBoxMediaSetup) { $completed += '箱シール: 設定ツールから校正・テスト印刷を実行できます。' }
    [void][Windows.Forms.MessageBox]::Show(
        ($completed -join "`r`n"),
        'D-CATS 初回設定 完了',
        [Windows.Forms.MessageBoxButtons]::OK,
        [Windows.Forms.MessageBoxIcon]::Information
    )
} catch {
    New-Item -ItemType Directory -Path $installRoot -Force | Out-Null
    $safeError = ($_.Exception.Message -replace '[\r\n]+', ' ').Trim()
    [IO.File]::WriteAllText((Join-Path $installRoot 'setup-error.log'), $safeError, [Text.UTF8Encoding]::new($false))
    [void][Windows.Forms.MessageBox]::Show($safeError, 'D-CATS 初回設定エラー', 'OK', 'Error')
    exit 1
} finally {
    $credential = $null
    $securePassword = $null
    $form.Dispose()
}
