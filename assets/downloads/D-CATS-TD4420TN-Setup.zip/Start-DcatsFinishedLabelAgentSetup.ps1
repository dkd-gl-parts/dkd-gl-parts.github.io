﻿[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$installRoot = Join-Path $env:LOCALAPPDATA 'D-CATS\FinishedLabelAgent'

$uiStrings = @{
    ja = @{
        LanguagePrompt = '設定画面で使用する言語を選択してください。'
        FormTitle = 'D-CATS TD-4420TN 初回設定'
        MainTitle = 'このPCをD-CATS印刷端末として登録'
        MainDescription = '45×20mmと80×60mmを物理プリンターへ割り当てます。Windowsの既定プリンターは変更しません。'
        ManualPrinter = '一覧にないプリンターをIPアドレスで指定'
        BoxLater = '後で設定する（箱シールは印刷待ちに送信できません）'
        Site = '拠点'
        Japan = 'JP | 日本'
        Philippines = 'PH | フィリピン'
        FinishedGroup = '完品シール（必須）  45 × 20 mm'
        BoxGroup = '箱シール（後から設定可能）  80 × 60 mm'
        Printer = 'プリンター'
        IpAddress = 'IPアドレス'
        MediaReady = "用紙・リボンをセット済み`r`n登録後に校正・テスト印刷"
        Authentication = 'D-CATS認証'
        Email = 'メールアドレス'
        Password = 'パスワード'
        PasswordNote = 'パスワードは保存しません。更新トークンだけをこのWindowsユーザー用に暗号化して保存します。'
        CheckConnection = 'プリンター接続確認'
        Register = 'このPCを印刷端末として登録'
        Cancel = 'キャンセル'
        InvalidIp = 'IPアドレスを正しく入力してください。'
        TcpFailed = 'プリンターのTCP 9100番ポートへ接続できません。電源とLAN接続を確認してください。'
        Connected = '接続できました。登録へ進めます。'
        NoPrinter = 'Windows登録済みプリンターがないため、IPアドレスを入力してください。'
        CredentialsRequired = 'D-CATSのメールアドレスとパスワードを入力してください。'
        FinishedAddressRequired = '完品シール用プリンターのIPアドレスを入力してください。'
        BoxAddressRequired = '箱シール用プリンターのIPアドレスを入力してください。'
        SeparatePrinters = '45×20mmと80×60mmは別の物理プリンターを選択してください。'
        Completed = '印刷端末の登録が完了しました。'
        FinishedTarget = '完品シール 45×20mm'
        BoxTarget = '箱シール 80×60mm'
        CalibrationCompleted = '校正・テスト印刷 完了'
        CalibrationReview = '登録済み / 校正・テスト印刷は要確認'
        CalibrationAvailable = '設定ツールから校正・テスト印刷を実行できます。'
        CompleteTitle = 'D-CATS 初回設定 完了'
        ErrorTitle = 'D-CATS 初回設定エラー'
    }
    en = @{
        LanguagePrompt = 'Choose the language for the setup tool.'
        FormTitle = 'D-CATS TD-4420TN First-Time Setup'
        MainTitle = 'Register This PC as a D-CATS Print Station'
        MainDescription = 'Assign 45 x 20 mm and 80 x 60 mm media to physical printers. The Windows default printer will not be changed.'
        ManualPrinter = 'Specify a printer not listed above by IP address'
        BoxLater = 'Set up later (box-label jobs cannot be sent yet)'
        Site = 'Site'
        Japan = 'JP | Japan'
        Philippines = 'PH | Philippines'
        FinishedGroup = 'Finished label (required)  45 x 20 mm'
        BoxGroup = 'Box label (can be set up later)  80 x 60 mm'
        Printer = 'Printer'
        IpAddress = 'IP address'
        MediaReady = "Media and ribbon are loaded`r`nCalibrate and test after registration"
        Authentication = 'D-CATS sign-in'
        Email = 'Email address'
        Password = 'Password'
        PasswordNote = 'The password is not stored. Only the refresh token is encrypted for this Windows user.'
        CheckConnection = 'Check printer connection'
        Register = 'Register this PC as a print station'
        Cancel = 'Cancel'
        InvalidIp = 'Enter a valid IP address.'
        TcpFailed = 'Cannot connect to TCP port 9100 on the printer. Check the printer power and LAN connection.'
        Connected = 'Connected. You can continue with registration.'
        NoPrinter = 'No registered Windows printer was found. Enter the printer IP address.'
        CredentialsRequired = 'Enter your D-CATS email address and password.'
        FinishedAddressRequired = 'Enter the IP address of the finished-label printer.'
        BoxAddressRequired = 'Enter the IP address of the box-label printer.'
        SeparatePrinters = 'Select different physical printers for 45 x 20 mm and 80 x 60 mm media.'
        Completed = 'Print-station registration is complete.'
        FinishedTarget = 'Finished label 45 x 20 mm'
        BoxTarget = 'Box label 80 x 60 mm'
        CalibrationCompleted = 'Calibration and test print completed'
        CalibrationReview = 'Registered / calibration or test print needs review'
        CalibrationAvailable = 'Calibration and test printing are available from the setup tool.'
        CompleteTitle = 'D-CATS Setup Complete'
        ErrorTitle = 'D-CATS Setup Error'
    }
    zh = @{
        LanguagePrompt = '请选择设置工具使用的语言。'
        FormTitle = 'D-CATS TD-4420TN 首次设置'
        MainTitle = '将此电脑注册为D-CATS打印终端'
        MainDescription = '将45×20mm和80×60mm纸张分配给实体打印机。不会更改Windows默认打印机。'
        ManualPrinter = '使用IP地址指定列表中没有的打印机'
        BoxLater = '稍后设置（暂时无法发送箱标签打印任务）'
        Site = '站点'
        Japan = 'JP | 日本'
        Philippines = 'PH | 菲律宾'
        FinishedGroup = '完品标签（必填）  45 × 20 mm'
        BoxGroup = '箱标签（可稍后设置）  80 × 60 mm'
        Printer = '打印机'
        IpAddress = 'IP地址'
        MediaReady = "已装入纸张和色带`r`n注册后校准并测试打印"
        Authentication = 'D-CATS登录'
        Email = '电子邮箱'
        Password = '密码'
        PasswordNote = '不会保存密码。仅为此Windows用户加密保存刷新令牌。'
        CheckConnection = '检查打印机连接'
        Register = '将此电脑注册为打印终端'
        Cancel = '取消'
        InvalidIp = '请输入正确的IP地址。'
        TcpFailed = '无法连接打印机的TCP 9100端口。请检查电源和LAN连接。'
        Connected = '连接成功，可以继续注册。'
        NoPrinter = '未找到Windows中已注册的打印机，请输入IP地址。'
        CredentialsRequired = '请输入D-CATS电子邮箱和密码。'
        FinishedAddressRequired = '请输入完品标签打印机的IP地址。'
        BoxAddressRequired = '请输入箱标签打印机的IP地址。'
        SeparatePrinters = '45×20mm和80×60mm请选择不同的实体打印机。'
        Completed = '打印终端注册完成。'
        FinishedTarget = '完品标签 45×20mm'
        BoxTarget = '箱标签 80×60mm'
        CalibrationCompleted = '校准和测试打印完成'
        CalibrationReview = '已注册 / 请检查校准或测试打印'
        CalibrationAvailable = '可从设置工具执行校准和测试打印。'
        CompleteTitle = 'D-CATS首次设置完成'
        ErrorTitle = 'D-CATS首次设置错误'
    }
}

function Select-SetupLanguage {
    $languageForm = [Windows.Forms.Form]::new()
    $languageForm.Text = 'D-CATS Language / 言語 / 语言'
    $languageForm.StartPosition = 'CenterScreen'
    $languageForm.ClientSize = [Drawing.Size]::new(440, 170)
    $languageForm.FormBorderStyle = [Windows.Forms.FormBorderStyle]::FixedDialog
    $languageForm.MaximizeBox = $false
    $languageForm.MinimizeBox = $false
    $languageForm.TopMost = $true
    $languageForm.Font = [Drawing.Font]::new('Yu Gothic UI', 10)

    $prompt = [Windows.Forms.Label]::new()
    $prompt.Location = [Drawing.Point]::new(24, 24)
    $prompt.Size = [Drawing.Size]::new(392, 38)
    $prompt.Text = 'Language / 言語 / 语言'
    $prompt.TextAlign = [Drawing.ContentAlignment]::MiddleCenter
    $prompt.Font = [Drawing.Font]::new('Yu Gothic UI', 14, [Drawing.FontStyle]::Bold)
    $languageForm.Controls.Add($prompt)

    $languageChoices = @(
        [pscustomobject]@{ Code = 'ja'; Label = '日本語' },
        [pscustomobject]@{ Code = 'en'; Label = 'English' },
        [pscustomobject]@{ Code = 'zh'; Label = '中文' }
    )
    for ($index = 0; $index -lt $languageChoices.Count; $index++) {
        $choice = $languageChoices[$index]
        $button = [Windows.Forms.Button]::new()
        $button.Location = [Drawing.Point]::new((24 + ($index * 136)), 82)
        $button.Size = [Drawing.Size]::new(120, 46)
        $button.Text = $choice.Label
        $button.Tag = $choice.Code
        $selectedCode = [string]$choice.Code
        $button.Add_Click({
            $languageForm.Tag = $selectedCode
            $languageForm.DialogResult = [Windows.Forms.DialogResult]::OK
            $languageForm.Close()
        }.GetNewClosure())
        $languageForm.Controls.Add($button)
    }

    $result = $languageForm.ShowDialog()
    $selectedLanguage = [string]$languageForm.Tag
    $languageForm.Dispose()
    if ($result -ne [Windows.Forms.DialogResult]::OK -or -not $uiStrings.ContainsKey($selectedLanguage)) { return '' }
    return $selectedLanguage
}

$uiLanguage = Select-SetupLanguage
if (-not $uiLanguage) { exit 1 }

function Get-UiText {
    param([Parameter(Mandatory = $true)][string]$Key)
    return [string]$uiStrings[$uiLanguage][$Key]
}

function Get-NetworkPrinterChoices {
    $choices = New-Object Collections.Generic.List[object]
    try {
        foreach ($printer in @(Get-Printer -ErrorAction Stop | Sort-Object Name)) {
            try {
                $port = Get-PrinterPort -Name $printer.PortName -ErrorAction Stop
                $address = ([string]$port.PrinterHostAddress).Trim()
                if (-not $address) { continue }
                $parsedAddress = $null
                if (-not [Net.IPAddress]::TryParse($address, [ref]$parsedAddress)) { continue }
                $choices.Add([pscustomobject]@{
                    Display = ('{0}  /  {1}' -f $printer.Name, $address)
                    Name = [string]$printer.Name
                    Address = $address
                    Kind = 'printer'
                })
            } catch {}
        }
    } catch {}
    return @($choices | ForEach-Object { $_ })
}

function Test-PrinterEndpoint {
    param([Parameter(Mandatory = $true)][string]$Address)

    $parsedAddress = $null
    if (-not [Net.IPAddress]::TryParse($Address, [ref]$parsedAddress)) {
        throw (Get-UiText 'InvalidIp')
    }
    $client = [Net.Sockets.TcpClient]::new()
    try {
        $task = $client.ConnectAsync($Address, 9100)
        if (-not $task.Wait(3000) -or -not $client.Connected) {
            throw (Get-UiText 'TcpFailed')
        }
    } finally {
        $client.Dispose()
    }
}

function Add-TextLabel {
    param(
        [Windows.Forms.Control]$Parent,
        [string]$Text,
        [int]$X,
        [int]$Y,
        [int]$Width,
        [int]$Height = 24,
        [bool]$Bold = $false
    )

    $label = [Windows.Forms.Label]::new()
    $label.Location = [Drawing.Point]::new($X, $Y)
    $label.Size = [Drawing.Size]::new($Width, $Height)
    $label.Text = $Text
    if ($Bold) { $label.Font = [Drawing.Font]::new('Yu Gothic UI', 10, [Drawing.FontStyle]::Bold) }
    $Parent.Controls.Add($label)
    return $label
}

$printerChoices = @(Get-NetworkPrinterChoices)
$manualFinishedChoice = [pscustomobject]@{
    Display = Get-UiText 'ManualPrinter'
    Name = 'Brother TD-4420TN / 45x20'
    Address = ''
    Kind = 'manual'
}
$manualBoxChoice = [pscustomobject]@{
    Display = Get-UiText 'ManualPrinter'
    Name = 'Brother TD-4420TN / 80x60'
    Address = ''
    Kind = 'manual'
}
$boxLaterChoice = [pscustomobject]@{
    Display = Get-UiText 'BoxLater'
    Name = ''
    Address = ''
    Kind = 'none'
}

$form = [Windows.Forms.Form]::new()
$form.Text = Get-UiText 'FormTitle'
$form.StartPosition = 'CenterScreen'
$form.ClientSize = [Drawing.Size]::new(780, 680)
$form.FormBorderStyle = [Windows.Forms.FormBorderStyle]::FixedDialog
$form.MaximizeBox = $false
$form.MinimizeBox = $false
$form.TopMost = $true
$form.Font = [Drawing.Font]::new('Yu Gothic UI', 10)

$title = Add-TextLabel -Parent $form -Text (Get-UiText 'MainTitle') -X 24 -Y 18 -Width 710 -Height 32 -Bold $true
$title.Font = [Drawing.Font]::new('Yu Gothic UI', 16, [Drawing.FontStyle]::Bold)
[void](Add-TextLabel -Parent $form -Text (Get-UiText 'MainDescription') -X 24 -Y 55 -Width 730 -Height 28)

[void](Add-TextLabel -Parent $form -Text (Get-UiText 'Site') -X 24 -Y 94 -Width 110 -Bold $true)
$siteBox = [Windows.Forms.ComboBox]::new()
$siteBox.Location = [Drawing.Point]::new(140, 90)
$siteBox.Size = [Drawing.Size]::new(260, 30)
$siteBox.DropDownStyle = [Windows.Forms.ComboBoxStyle]::DropDownList
[void]$siteBox.Items.Add((Get-UiText 'Japan'))
[void]$siteBox.Items.Add((Get-UiText 'Philippines'))
$siteBox.SelectedIndex = 0
$form.Controls.Add($siteBox)

$finishedGroup = [Windows.Forms.GroupBox]::new()
$finishedGroup.Text = Get-UiText 'FinishedGroup'
$finishedGroup.Location = [Drawing.Point]::new(24, 132)
$finishedGroup.Size = [Drawing.Size]::new(732, 145)
$form.Controls.Add($finishedGroup)
[void](Add-TextLabel -Parent $finishedGroup -Text (Get-UiText 'Printer') -X 16 -Y 31 -Width 105 -Bold $true)
$finishedBox = [Windows.Forms.ComboBox]::new()
$finishedBox.Location = [Drawing.Point]::new(126, 28)
$finishedBox.Size = [Drawing.Size]::new(580, 30)
$finishedBox.DropDownStyle = [Windows.Forms.ComboBoxStyle]::DropDownList
$finishedBox.DisplayMember = 'Display'
foreach ($choice in $printerChoices) { [void]$finishedBox.Items.Add($choice) }
[void]$finishedBox.Items.Add($manualFinishedChoice)
$finishedBox.SelectedIndex = 0
$finishedGroup.Controls.Add($finishedBox)
[void](Add-TextLabel -Parent $finishedGroup -Text (Get-UiText 'IpAddress') -X 16 -Y 72 -Width 105 -Bold $true)
$finishedAddressBox = [Windows.Forms.TextBox]::new()
$finishedAddressBox.Location = [Drawing.Point]::new(126, 69)
$finishedAddressBox.Size = [Drawing.Size]::new(280, 30)
$finishedGroup.Controls.Add($finishedAddressBox)
$finishedReadyCheck = [Windows.Forms.CheckBox]::new()
$finishedReadyCheck.Location = [Drawing.Point]::new(426, 68)
$finishedReadyCheck.Size = [Drawing.Size]::new(280, 46)
$finishedReadyCheck.Text = Get-UiText 'MediaReady'
$finishedGroup.Controls.Add($finishedReadyCheck)

$boxGroup = [Windows.Forms.GroupBox]::new()
$boxGroup.Text = Get-UiText 'BoxGroup'
$boxGroup.Location = [Drawing.Point]::new(24, 290)
$boxGroup.Size = [Drawing.Size]::new(732, 145)
$form.Controls.Add($boxGroup)
[void](Add-TextLabel -Parent $boxGroup -Text (Get-UiText 'Printer') -X 16 -Y 31 -Width 105 -Bold $true)
$boxBox = [Windows.Forms.ComboBox]::new()
$boxBox.Location = [Drawing.Point]::new(126, 28)
$boxBox.Size = [Drawing.Size]::new(580, 30)
$boxBox.DropDownStyle = [Windows.Forms.ComboBoxStyle]::DropDownList
$boxBox.DisplayMember = 'Display'
[void]$boxBox.Items.Add($boxLaterChoice)
foreach ($choice in $printerChoices) { [void]$boxBox.Items.Add($choice) }
[void]$boxBox.Items.Add($manualBoxChoice)
$boxBox.SelectedIndex = 0
$boxGroup.Controls.Add($boxBox)
[void](Add-TextLabel -Parent $boxGroup -Text (Get-UiText 'IpAddress') -X 16 -Y 72 -Width 105 -Bold $true)
$boxAddressBox = [Windows.Forms.TextBox]::new()
$boxAddressBox.Location = [Drawing.Point]::new(126, 69)
$boxAddressBox.Size = [Drawing.Size]::new(280, 30)
$boxAddressBox.Enabled = $false
$boxGroup.Controls.Add($boxAddressBox)
$boxReadyCheck = [Windows.Forms.CheckBox]::new()
$boxReadyCheck.Location = [Drawing.Point]::new(426, 68)
$boxReadyCheck.Size = [Drawing.Size]::new(280, 46)
$boxReadyCheck.Text = Get-UiText 'MediaReady'
$boxReadyCheck.Enabled = $false
$boxGroup.Controls.Add($boxReadyCheck)

[void](Add-TextLabel -Parent $form -Text (Get-UiText 'Authentication') -X 24 -Y 456 -Width 125 -Bold $true)
[void](Add-TextLabel -Parent $form -Text (Get-UiText 'Email') -X 24 -Y 492 -Width 125)
$emailBox = [Windows.Forms.TextBox]::new()
$emailBox.Location = [Drawing.Point]::new(155, 488)
$emailBox.Size = [Drawing.Size]::new(280, 30)
$form.Controls.Add($emailBox)
[void](Add-TextLabel -Parent $form -Text (Get-UiText 'Password') -X 450 -Y 492 -Width 90)
$passwordBox = [Windows.Forms.TextBox]::new()
$passwordBox.Location = [Drawing.Point]::new(545, 488)
$passwordBox.Size = [Drawing.Size]::new(211, 30)
$passwordBox.UseSystemPasswordChar = $true
$form.Controls.Add($passwordBox)
[void](Add-TextLabel -Parent $form -Text (Get-UiText 'PasswordNote') -X 155 -Y 523 -Width 600 -Height 27)

$connectionButton = [Windows.Forms.Button]::new()
$connectionButton.Location = [Drawing.Point]::new(24, 570)
$connectionButton.Size = [Drawing.Size]::new(190, 38)
$connectionButton.Text = Get-UiText 'CheckConnection'
$form.Controls.Add($connectionButton)
$statusLabel = Add-TextLabel -Parent $form -Text '' -X 225 -Y 578 -Width 270 -Height 28
$statusLabel.ForeColor = [Drawing.Color]::FromArgb(31, 93, 66)

$installButton = [Windows.Forms.Button]::new()
$installButton.Location = [Drawing.Point]::new(506, 563)
$installButton.Size = [Drawing.Size]::new(250, 46)
$installButton.Text = Get-UiText 'Register'
$installButton.BackColor = [Drawing.Color]::FromArgb(28, 92, 67)
$installButton.ForeColor = [Drawing.Color]::White
$installButton.FlatStyle = [Windows.Forms.FlatStyle]::Flat
$form.Controls.Add($installButton)

$cancelButton = [Windows.Forms.Button]::new()
$cancelButton.Location = [Drawing.Point]::new(651, 625)
$cancelButton.Size = [Drawing.Size]::new(105, 34)
$cancelButton.Text = Get-UiText 'Cancel'
$cancelButton.DialogResult = [Windows.Forms.DialogResult]::Cancel
$form.Controls.Add($cancelButton)

function Sync-PrinterChoice {
    param(
        [Windows.Forms.ComboBox]$Selector,
        [Windows.Forms.TextBox]$AddressBox,
        [Windows.Forms.CheckBox]$ReadyCheck
    )

    $selected = $Selector.SelectedItem
    $disabled = -not $selected -or [string]$selected.Kind -eq 'none'
    $AddressBox.Enabled = -not $disabled
    $ReadyCheck.Enabled = -not $disabled
    if ($disabled) {
        $AddressBox.Clear()
        $ReadyCheck.Checked = $false
    } elseif ([string]$selected.Kind -eq 'printer') {
        $AddressBox.Text = [string]$selected.Address
    } else {
        $AddressBox.Clear()
        $AddressBox.Focus()
    }
}

function Selected-PrinterName {
    param([Windows.Forms.ComboBox]$Selector, [string]$Fallback)
    $selected = $Selector.SelectedItem
    if ($selected -and [string]$selected.Kind -eq 'printer') { return [string]$selected.Name }
    if ($selected -and [string]$selected.Kind -eq 'none') { return '' }
    return $Fallback
}

$finishedBox.Add_SelectedIndexChanged({ Sync-PrinterChoice -Selector $finishedBox -AddressBox $finishedAddressBox -ReadyCheck $finishedReadyCheck })
$boxBox.Add_SelectedIndexChanged({ Sync-PrinterChoice -Selector $boxBox -AddressBox $boxAddressBox -ReadyCheck $boxReadyCheck })
Sync-PrinterChoice -Selector $finishedBox -AddressBox $finishedAddressBox -ReadyCheck $finishedReadyCheck

$connectionButton.Add_Click({
    try {
        Test-PrinterEndpoint -Address $finishedAddressBox.Text.Trim()
        if ($boxAddressBox.Enabled) { Test-PrinterEndpoint -Address $boxAddressBox.Text.Trim() }
        $statusLabel.Text = Get-UiText 'Connected'
        $statusLabel.ForeColor = [Drawing.Color]::FromArgb(31, 93, 66)
    } catch {
        $statusLabel.Text = $_.Exception.Message
        $statusLabel.ForeColor = [Drawing.Color]::FromArgb(168, 40, 40)
    }
})

$form.AcceptButton = $installButton
$form.CancelButton = $cancelButton
$form.Add_Shown({
    if ($printerChoices.Count -eq 0) {
        $statusLabel.Text = Get-UiText 'NoPrinter'
    }
})

$installButton.Add_Click({
    if ([string]::IsNullOrWhiteSpace($emailBox.Text) -or [string]::IsNullOrWhiteSpace($passwordBox.Text)) {
        [void][Windows.Forms.MessageBox]::Show($form, (Get-UiText 'CredentialsRequired'), (Get-UiText 'FormTitle'), 'OK', 'Warning')
        return
    }
    if ([string]::IsNullOrWhiteSpace($finishedAddressBox.Text)) {
        [void][Windows.Forms.MessageBox]::Show($form, (Get-UiText 'FinishedAddressRequired'), (Get-UiText 'FormTitle'), 'OK', 'Warning')
        return
    }
    if ($boxAddressBox.Enabled -and [string]::IsNullOrWhiteSpace($boxAddressBox.Text)) {
        [void][Windows.Forms.MessageBox]::Show($form, (Get-UiText 'BoxAddressRequired'), (Get-UiText 'FormTitle'), 'OK', 'Warning')
        return
    }
    if ($boxAddressBox.Enabled -and $finishedAddressBox.Text.Trim() -eq $boxAddressBox.Text.Trim()) {
        [void][Windows.Forms.MessageBox]::Show($form, (Get-UiText 'SeparatePrinters'), (Get-UiText 'FormTitle'), 'OK', 'Warning')
        return
    }
    $form.DialogResult = [Windows.Forms.DialogResult]::OK
    $form.Close()
})

$dialogResult = $form.ShowDialog()
if ($dialogResult -ne [Windows.Forms.DialogResult]::OK) {
    $form.Dispose()
    exit 1
}

$selectedSite = if ([string]$siteBox.SelectedItem -like 'PH*') { 'PH' } else { 'JP' }
$finishedPrinterName = Selected-PrinterName -Selector $finishedBox -Fallback 'Brother TD-4420TN / 45x20'
$boxPrinterName = Selected-PrinterName -Selector $boxBox -Fallback 'Brother TD-4420TN / 80x60'
$finishedPrinterAddress = $finishedAddressBox.Text.Trim()
$boxPrinterAddress = if ($boxAddressBox.Enabled) { $boxAddressBox.Text.Trim() } else { '' }
$runFinishedMediaSetup = $finishedReadyCheck.Checked
$runBoxMediaSetup = $boxReadyCheck.Checked -and $boxAddressBox.Enabled
$securePassword = ConvertTo-SecureString $passwordBox.Text -AsPlainText -Force
$credential = [Management.Automation.PSCredential]::new($emailBox.Text.Trim(), $securePassword)
$passwordBox.Clear()

try {
    $installer = Join-Path $PSScriptRoot 'Install-DcatsFinishedLabelAgent.ps1'
    $result = & $installer `
        -Email $credential.UserName `
        -Credential $credential `
        -SiteCode $selectedSite `
        -FinishedPrinterName $finishedPrinterName `
        -FinishedPrinterAddress $finishedPrinterAddress `
        -BoxPrinterName $boxPrinterName `
        -BoxPrinterAddress $boxPrinterAddress

    $completed = @((Get-UiText 'Completed'), [string]($result | Select-Object -Last 1))
    foreach ($target in @(
        [pscustomobject]@{ Enabled = $runFinishedMediaSetup; Code = 'finished_product'; Name = Get-UiText 'FinishedTarget' },
        [pscustomobject]@{ Enabled = $runBoxMediaSetup; Code = 'box'; Name = Get-UiText 'BoxTarget' }
    )) {
        if (-not $target.Enabled) { continue }
        try {
            & (Join-Path $installRoot 'Calibrate-DcatsLabelPrinter.ps1') -LabelTarget $target.Code -ConfirmMediaLoaded | Out-Null
            & (Join-Path $installRoot 'Test-DcatsLabelPrinter.ps1') -LabelTarget $target.Code | Out-Null
            $completed += ($target.Name + ': ' + (Get-UiText 'CalibrationCompleted'))
        } catch {
            $completed += ($target.Name + ': ' + (Get-UiText 'CalibrationReview') + ' - ' + $_.Exception.Message)
        }
    }
    if (-not $runFinishedMediaSetup) { $completed += ((Get-UiText 'FinishedTarget') + ': ' + (Get-UiText 'CalibrationAvailable')) }
    if ($boxAddressBox.Enabled -and -not $runBoxMediaSetup) { $completed += ((Get-UiText 'BoxTarget') + ': ' + (Get-UiText 'CalibrationAvailable')) }
    [void][Windows.Forms.MessageBox]::Show(
        ($completed -join "`r`n"),
        (Get-UiText 'CompleteTitle'),
        [Windows.Forms.MessageBoxButtons]::OK,
        [Windows.Forms.MessageBoxIcon]::Information
    )
} catch {
    New-Item -ItemType Directory -Path $installRoot -Force | Out-Null
    $safeError = ($_.Exception.Message -replace '[\r\n]+', ' ').Trim()
    [IO.File]::WriteAllText((Join-Path $installRoot 'setup-error.log'), $safeError, [Text.UTF8Encoding]::new($false))
    [void][Windows.Forms.MessageBox]::Show($safeError, (Get-UiText 'ErrorTitle'), 'OK', 'Error')
    exit 1
} finally {
    $credential = $null
    $securePassword = $null
    $form.Dispose()
}
