[CmdletBinding()]
param(
    [string]$Email = '',
    [Management.Automation.PSCredential]$Credential,
    [ValidateSet('JP', 'PH')][string]$SiteCode = 'JP',
    [string]$FinishedPrinterName = 'Brother TD-4420TN',
    [string]$FinishedPrinterAddress = '',
    [int]$FinishedPrinterPort = 9100,
    [string]$BoxPrinterName = '',
    [string]$BoxPrinterAddress = '',
    [int]$BoxPrinterPort = 9100,
    [string]$InstallRoot = (Join-Path $env:LOCALAPPDATA 'D-CATS\FinishedLabelAgent')
)

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
Add-Type -AssemblyName System.Security

$taskName = 'D-CATS Finished Label Background Agent'
$projectRef = 'jqoeqximtwfpqwzngutj'
$supabaseUrl = 'https://jqoeqximtwfpqwzngutj.supabase.co'
$publishableKey = 'sb_publishable_TXdCwBQOD_s3N0TqFCDOAw_8B44a0kv'
$agentSource = Join-Path $PSScriptRoot 'DcatsFinishedLabelAgent.ps1'
$agentTarget = Join-Path $InstallRoot 'DcatsFinishedLabelAgent.ps1'
$calibratorSource = Join-Path $PSScriptRoot 'Calibrate-DcatsLabelPrinter.ps1'
$calibratorTarget = Join-Path $InstallRoot 'Calibrate-DcatsLabelPrinter.ps1'
$testPrinterSource = Join-Path $PSScriptRoot 'Test-DcatsLabelPrinter.ps1'
$testPrinterTarget = Join-Path $InstallRoot 'Test-DcatsLabelPrinter.ps1'
$actionLauncherSource = Join-Path $PSScriptRoot 'Invoke-DcatsLabelPrinterAction.ps1'
$actionLauncherTarget = Join-Path $InstallRoot 'Invoke-DcatsLabelPrinterAction.ps1'
$setupSource = Join-Path $PSScriptRoot 'Start-DcatsFinishedLabelAgentSetup.ps1'
$setupTarget = Join-Path $InstallRoot 'Start-DcatsFinishedLabelAgentSetup.ps1'
$installerTarget = Join-Path $InstallRoot 'Install-DcatsFinishedLabelAgent.ps1'
$statusSource = Join-Path $PSScriptRoot 'Get-DcatsFinishedLabelAgentStatus.ps1'
$statusTarget = Join-Path $InstallRoot 'Get-DcatsFinishedLabelAgentStatus.ps1'
$uninstallerSource = Join-Path $PSScriptRoot 'Uninstall-DcatsFinishedLabelAgent.ps1'
$uninstallerTarget = Join-Path $InstallRoot 'Uninstall-DcatsFinishedLabelAgent.ps1'
$configPath = Join-Path $InstallRoot 'config.json'
$authPath = Join-Path $InstallRoot 'auth.dpapi'
$entropy = [Text.Encoding]::UTF8.GetBytes('D-CATS Finished Label Agent v1')

if (-not (Test-Path -LiteralPath $agentSource)) {
    throw 'The background agent source file is missing.'
}
if (-not (Test-Path -LiteralPath $calibratorSource)) {
    throw 'The label-printer calibration script is missing.'
}
foreach ($requiredSource in @($testPrinterSource, $actionLauncherSource, $setupSource, $statusSource, $uninstallerSource)) {
    if (-not (Test-Path -LiteralPath $requiredSource)) {
        throw ('The setup package is incomplete: {0}' -f [IO.Path]::GetFileName($requiredSource))
    }
}

function Copy-AgentFile {
    param(
        [Parameter(Mandatory = $true)][string]$Source,
        [Parameter(Mandatory = $true)][string]$Destination
    )

    if ([IO.Path]::GetFullPath($Source) -eq [IO.Path]::GetFullPath($Destination)) { return }
    Copy-Item -LiteralPath $Source -Destination $Destination -Force
}

function Resolve-PrinterEndpoint {
    param(
        [Parameter(Mandatory = $true)][string]$Role,
        [string]$PrinterName,
        [string]$PrinterAddress,
        [int]$PrinterPort
    )

    if (-not $PrinterAddress) {
        if (-not $PrinterName) { throw ('Select the {0} printer.' -f $Role) }
        $printer = Get-Printer -Name $PrinterName -ErrorAction Stop
        $port = Get-PrinterPort -Name $printer.PortName -ErrorAction Stop
        $PrinterAddress = [string]$port.PrinterHostAddress
    }
    if (-not $PrinterAddress) { throw ('A network address could not be resolved for the {0} printer.' -f $Role) }
    $parsedAddress = $null
    if (-not [Net.IPAddress]::TryParse($PrinterAddress, [ref]$parsedAddress)) {
        throw ('The {0} printer address must be an IPv4 or IPv6 address.' -f $Role)
    }
    $probe = [Net.Sockets.TcpClient]::new()
    try {
        $probeTask = $probe.ConnectAsync($PrinterAddress, $PrinterPort)
        if (-not $probeTask.Wait(3000) -or -not $probe.Connected) {
            throw ('The {0} printer did not accept a TCP connection.' -f $Role)
        }
    } finally {
        $probe.Dispose()
    }
    return [pscustomobject]@{ Name = $PrinterName; Address = $PrinterAddress; Port = $PrinterPort }
}

$finishedPrinter = Resolve-PrinterEndpoint -Role 'finished-label' -PrinterName $FinishedPrinterName -PrinterAddress $FinishedPrinterAddress -PrinterPort $FinishedPrinterPort
$boxRequested = -not [string]::IsNullOrWhiteSpace($BoxPrinterName) -or -not [string]::IsNullOrWhiteSpace($BoxPrinterAddress)
$boxPrinter = if ($boxRequested) {
    Resolve-PrinterEndpoint -Role 'box-label' -PrinterName $BoxPrinterName -PrinterAddress $BoxPrinterAddress -PrinterPort $BoxPrinterPort
} else {
    $null
}
if ($boxPrinter -and $finishedPrinter.Address -eq $boxPrinter.Address -and $finishedPrinter.Port -eq $boxPrinter.Port) {
    throw 'The finished-label and box-label printers must be different network printers.'
}
$finishedPrinterCode = if ($SiteCode -eq 'PH') { 'PH-TD-4420TN-45X20' } else { 'TD-4420TN-45X20' }
$boxPrinterCode = if ($SiteCode -eq 'PH') { 'PH-TD-4420TN-80X60' } else { 'TD-4420TN-80X60' }

if (-not $Credential) {
    $Credential = Get-Credential -UserName $Email -Message 'Enter your D-CATS password once. The password will not be stored.'
}
if (-not $credential) {
    throw 'D-CATS sign-in was cancelled.'
}

$plainPassword = $Credential.GetNetworkCredential().Password
try {
    $signInBody = @{
        email = $Credential.UserName
        password = $plainPassword
    } | ConvertTo-Json -Compress
    $session = Invoke-RestMethod `
        -Method Post `
        -Uri ($supabaseUrl + '/auth/v1/token?grant_type=password') `
        -Headers @{ apikey = $publishableKey } `
        -ContentType 'application/json' `
        -Body $signInBody `
        -TimeoutSec 20 `
        -DisableKeepAlive `
        -UseBasicParsing
} finally {
    $plainPassword = $null
    $signInBody = $null
    $Credential = $null
}

if (-not $session.access_token -or -not $session.refresh_token) {
    throw 'D-CATS sign-in did not return a complete session.'
}

$permissionHeaders = @{
    apikey = $publishableKey
    Authorization = 'Bearer ' + [string]$session.access_token
}
$stations = Invoke-RestMethod `
    -Method Post `
    -Uri ($supabaseUrl + '/rest/v1/rpc/list_finished_label_print_stations') `
    -Headers $permissionHeaders `
    -ContentType 'application/json' `
    -Body (@{ target_label_target = $null } | ConvertTo-Json -Compress) `
    -TimeoutSec 20 `
    -DisableKeepAlive `
    -UseBasicParsing
$stationCodes = @($stations | ForEach-Object { [string]$_.printer_code })
$requiredStationCodes = @($finishedPrinterCode)
if ($boxPrinter) { $requiredStationCodes += $boxPrinterCode }
foreach ($requiredStationCode in $requiredStationCodes) {
    if ($requiredStationCode -notin $stationCodes) {
        throw ('The {0} printer destination {1} is not enabled in D-CATS.' -f $SiteCode, $requiredStationCode)
    }
}

New-Item -ItemType Directory -Path $InstallRoot -Force | Out-Null
Copy-AgentFile -Source $agentSource -Destination $agentTarget
Copy-AgentFile -Source $calibratorSource -Destination $calibratorTarget
Copy-AgentFile -Source $testPrinterSource -Destination $testPrinterTarget
Copy-AgentFile -Source $actionLauncherSource -Destination $actionLauncherTarget
Copy-AgentFile -Source $setupSource -Destination $setupTarget
Copy-AgentFile -Source $PSCommandPath -Destination $installerTarget
Copy-AgentFile -Source $statusSource -Destination $statusTarget
Copy-AgentFile -Source $uninstallerSource -Destination $uninstallerTarget

$printerConfigs = @(
    [ordered]@{
        printerCode = $finishedPrinterCode
        siteCode = $SiteCode
        labelTarget = 'finished_product'
        labelFormat = '45x20'
        profileName = 'D-CATS Finished Label 45x20'
        mediaWidthMm = 45
        mediaHeightMm = 20
        dpi = 203
        mediaTracking = 'gap'
        printMethod = 'thermal_transfer'
        printerName = $finishedPrinter.Name
        printerAddress = $finishedPrinter.Address
        printerPort = $finishedPrinter.Port
        enabled = $true
    }
)
if ($boxPrinter) {
    $printerConfigs += [ordered]@{
        printerCode = $boxPrinterCode
        siteCode = $SiteCode
        labelTarget = 'box'
        labelFormat = '80x60'
        profileName = 'D-CATS Box Label 80x60'
        mediaWidthMm = 80
        mediaHeightMm = 60
        dpi = 203
        mediaTracking = 'gap'
        printMethod = 'thermal_transfer'
        printerName = $boxPrinter.Name
        printerAddress = $boxPrinter.Address
        printerPort = $boxPrinter.Port
        enabled = $true
    }
}

$config = [ordered]@{
    version = 3
    supabaseProjectRef = $projectRef
    supabaseUrl = $supabaseUrl
    supabasePublishableKey = $publishableKey
    siteCode = $SiteCode
    printers = $printerConfigs
    pollSeconds = 4
    errorRetrySeconds = 15
    connectTimeoutMs = 5000
    sendTimeoutMs = 5000
}
[IO.File]::WriteAllText(
    $configPath,
    ($config | ConvertTo-Json -Depth 5),
    [Text.UTF8Encoding]::new($false)
)

$refreshBytes = [Text.Encoding]::UTF8.GetBytes([string]$session.refresh_token)
try {
    $protectedBytes = [Security.Cryptography.ProtectedData]::Protect(
        $refreshBytes,
        $entropy,
        [Security.Cryptography.DataProtectionScope]::CurrentUser
    )
    [IO.File]::WriteAllBytes($authPath, $protectedBytes)
} finally {
    [Array]::Clear($refreshBytes, 0, $refreshBytes.Length)
    $session = $null
}

$currentIdentity = [Security.Principal.WindowsIdentity]::GetCurrent().Name
$action = New-ScheduledTaskAction `
    -Execute 'powershell.exe' `
    -Argument ('-NoProfile -NonInteractive -WindowStyle Hidden -ExecutionPolicy Bypass -File "{0}"' -f $agentTarget)
$trigger = New-ScheduledTaskTrigger -AtLogOn -User $currentIdentity
$principal = New-ScheduledTaskPrincipal -UserId $currentIdentity -LogonType Interactive -RunLevel Limited
$settings = New-ScheduledTaskSettingsSet `
    -AllowStartIfOnBatteries `
    -DontStopIfGoingOnBatteries `
    -StartWhenAvailable `
    -MultipleInstances IgnoreNew `
    -RestartCount 999 `
    -RestartInterval (New-TimeSpan -Minutes 1) `
    -ExecutionTimeLimit ([TimeSpan]::Zero)

Register-ScheduledTask `
    -TaskName $taskName `
    -Action $action `
    -Trigger $trigger `
    -Principal $principal `
    -Settings $settings `
    -Description 'Receives D-CATS finished-label jobs in the background and sends ZPL directly to Brother TD-4420TN.' `
    -Force | Out-Null

$protocolRoot = 'HKCU:\Software\Classes\dcats-label-printer'
$protocolCommand = Join-Path $protocolRoot 'shell\open\command'
New-Item -Path $protocolCommand -Force | Out-Null
Set-Item -Path $protocolRoot -Value 'URL:D-CATS Label Printer'
New-ItemProperty -Path $protocolRoot -Name 'URL Protocol' -Value '' -PropertyType String -Force | Out-Null
Set-Item -Path $protocolCommand -Value ('powershell.exe -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File "{0}" "%1"' -f $actionLauncherTarget)

Start-ScheduledTask -TaskName $taskName
Write-Output ('Installed the {0} background agent for {1} printer(s). No browser window is required.' -f $SiteCode, $printerConfigs.Count)
