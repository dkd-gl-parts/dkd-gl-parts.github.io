[CmdletBinding()]
param(
    [ValidateSet('finished_product', 'box')][string]$LabelTarget = 'finished_product',
    [switch]$ConfirmMediaLoaded,
    [string]$InstallRoot = (Join-Path $env:LOCALAPPDATA 'D-CATS\FinishedLabelAgent')
)

$ErrorActionPreference = 'Stop'
$taskName = 'D-CATS Finished Label Background Agent'
$configPath = Join-Path $InstallRoot 'config.json'

if (-not $ConfirmMediaLoaded) {
    throw 'Load the label roll and thermal-transfer ribbon, close the print head, and rerun with -ConfirmMediaLoaded.'
}
if (-not (Test-Path -LiteralPath $configPath)) {
    throw 'The D-CATS finished-label agent configuration is missing.'
}

$config = [IO.File]::ReadAllText($configPath, [Text.Encoding]::UTF8) | ConvertFrom-Json
$printers = @($config.printers | Where-Object {
    ($null -eq $_.enabled -or [bool]$_.enabled) -and [string]$_.labelTarget -eq $LabelTarget
})
if ($printers.Count -ne 1) {
    throw ('Exactly one enabled {0} printer must be configured.' -f $LabelTarget)
}
$printer = $printers[0]
if (-not [string]$printer.printerAddress -or [int]$printer.printerPort -lt 1) {
    throw 'The configured printer has no usable network endpoint.'
}

$task = Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue
$restartTask = $task -and [string]$task.State -eq 'Running'
$mutex = $null
$ownsMutex = $false
try {
    if ($restartTask) {
        Stop-ScheduledTask -TaskName $taskName
        for ($attempt = 0; $attempt -lt 40; $attempt += 1) {
            if ([string](Get-ScheduledTask -TaskName $taskName).State -ne 'Running') { break }
            Start-Sleep -Milliseconds 250
        }
    }

    $sid = [Security.Principal.WindowsIdentity]::GetCurrent().User.Value -replace '[^A-Za-z0-9]', '_'
    $mutex = [Threading.Mutex]::new($false, 'Local\DcatsFinishedLabelAgent_' + $sid)
    try {
        $ownsMutex = $mutex.WaitOne(10000)
    } catch [Threading.AbandonedMutexException] {
        # Stopping the long-running agent releases its process-owned mutex this way.
        $ownsMutex = $true
    }
    if (-not $ownsMutex) {
        throw 'The print agent did not become idle. Wait until the current label finishes and try again.'
    }

    $commands = "^XA`r`n^MNY`r`n^MTT`r`n^MFC,C`r`n^JUS`r`n^XZ`r`n~JC`r`n"
    $bytes = [Text.Encoding]::ASCII.GetBytes($commands)
    $client = [Net.Sockets.TcpClient]::new()
    $stream = $null
    try {
        $client.NoDelay = $true
        $client.SendTimeout = 5000
        $connectTask = $client.ConnectAsync([string]$printer.printerAddress, [int]$printer.printerPort)
        if (-not $connectTask.Wait(5000) -or -not $client.Connected) {
            throw 'Timed out connecting to the Brother label printer.'
        }
        $stream = $client.GetStream()
        $stream.WriteTimeout = 5000
        $stream.Write($bytes, 0, $bytes.Length)
        $stream.Flush()
    } finally {
        if ($stream) { $stream.Dispose() }
        $client.Dispose()
        [Array]::Clear($bytes, 0, $bytes.Length)
    }

    Start-Sleep -Seconds 8
    Write-Output ('Calibrated {0} for thermal-transfer gap labels. The printer may feed several blank labels.' -f [string]$printer.printerCode)
} finally {
    if ($ownsMutex) { [void]$mutex.ReleaseMutex() }
    if ($mutex) { $mutex.Dispose() }
    if ($restartTask) { Start-ScheduledTask -TaskName $taskName }
}
