# D-CATS 完品・箱シール バックグラウンド印刷

スマホから登録された印刷ジョブを、Windowsの非表示バックグラウンドタスクが受信し、同じ拠点に設置した2台のBrotherネットワークプリンターへZPLで直接送信します。

## 特徴

- Chrome、印刷プレビュー、専用画面を使用しません。
- Windowsの既定プリンターを変更しません。
- D-CATSのパスワードは保存しません。
- Supabaseの更新トークンのみをWindows DPAPI（CurrentUser）で暗号化します。
- 完品シール（45×20mm）と箱シール（80×60mm）は、別々のプリンターへ送信します。
- プリンターのLANポート9100へ直接送るため、対象はネットワーク接続されたBrother ZPL対応プリンターです。
- プリンターを自動探索しません。初回設定で選択した2台のIPアドレスだけを、このWindows PC内へ保存します。
- D-CATS/Supabase側にはIPアドレスを保存せず、`JP` または `PH` と論理プリンターコードだけを保存します。
- Windowsへ対象ユーザーがログインしている間、4秒間隔で印刷キューを確認します。
- D-CATS専用プロファイルとして、完品シール45×20mmと箱シール80×60mmの用紙寸法、203dpi、ギャップ紙、熱転写を登録します。
- 導入後はD-CATS画面から、再設定、状態確認、センサー校正、テスト印刷を起動できます。

## 導入

D-CATSから初回設定パッケージをダウンロードして展開し、`D-CATS-Printer-Setup.cmd` を開きます。最初に日本語・英語・中国語から表示言語を選択できます。設定画面では次を一度に行います。

1. 拠点を選択
2. 完品シール45×20mm用プリンターを選択またはIPアドレスで指定
3. 箱シール80×60mm用プリンターを選択またはIPアドレスで指定
4. D-CATSへ一度だけログイン
5. 用紙をセット済みのプリンターを校正し、テストラベルを印刷

Windowsへプリンターが登録済みなら一覧から選べます。ドライバーが未登録でも、TD-4420TNのIPアドレスが分かれば直接設定できます。

スクリプトから直接開く場合：

```powershell
& .\Start-DcatsFinishedLabelAgentSetup.ps1
```

画面を使用できない場合は、Windows PowerShellで次を実行します。

```powershell
& .\Install-DcatsFinishedLabelAgent.ps1
```

認証権限確認後、Windowsタスク `D-CATS Finished Label Background Agent` とD-CATS専用URLプロトコル `dcats-label-printer` が現在のWindowsユーザーへ登録され、バックグラウンド受信を開始します。

## 状態確認

```powershell
& .\Get-DcatsFinishedLabelAgentStatus.ps1
```

D-CATS画面の「状態確認」から開く場合：

```text
dcats-label-printer://status
```

ログにはジョブIDと成否だけを記録し、アクセストークン・更新トークン・パスワードは記録しません。

## 印字位置が1枚ごとにずれる場合

完品シールと熱転写リボンを正しく装着してヘッドを閉じた状態で、次を1回実行します。ギャップセンサーとリボンセンサーを校正するため、空ラベルが数枚送られることがあります。

```powershell
& "$env:LOCALAPPDATA\D-CATS\FinishedLabelAgent\Calibrate-DcatsLabelPrinter.ps1" -LabelTarget finished_product -ConfirmMediaLoaded
```

校正時に、用紙をギャップ紙、印刷方式を熱転写に設定し、電源投入時とヘッドを閉じた時の再校正も有効にします。用紙またはリボンを交換した後に位置がずれる場合も同じ操作を行います。通常の印刷ジョブにはギャップ紙指定を含めるため、1枚ごとの送り量の誤差は累積しません。

テスト印刷は次で実行できます。

```powershell
& "$env:LOCALAPPDATA\D-CATS\FinishedLabelAgent\Test-DcatsLabelPrinter.ps1" -LabelTarget finished_product
& "$env:LOCALAPPDATA\D-CATS\FinishedLabelAgent\Test-DcatsLabelPrinter.ps1" -LabelTarget box
```

## 解除

タスクだけを解除し、暗号化済み認証を残す場合：

```powershell
& .\Uninstall-DcatsFinishedLabelAgent.ps1
```

暗号化済み認証を含むローカル設定も削除する場合：

```powershell
& .\Uninstall-DcatsFinishedLabelAgent.ps1 -RemoveEncryptedAuthentication
```

## 振り分け

| 拠点 | 完品シール | 箱シール |
|---|---|---|
| 日本 | `TD-4420TN-45X20` | `TD-4420TN-80X60` |
| フィリピン | `PH-TD-4420TN-45X20` | `PH-TD-4420TN-80X60` |

スマホでは拠点を選びます。完品シール画面ではその拠点の45×20mmプリンター、箱シール画面では同じ拠点の80×60mmプリンターが自動選択されます。

## 印刷仕様

- 完品シール：45×20mm、203dpi、360×160dot
- 箱シール：80×60mm、203dpi、640×480dot
- 完品シール印字原点：上端の丸角を避けるため下へ20dot補正（QRは下端余白確保のため相対位置を2dot上へ補正）
- 完品シール横位置：文字とQRの大きさを維持し、左端を右へ8dot、使用幅を8dot縮小
- 完品シール見出し：PRODUCT ID・GLTEK PART NO.・MFG SERIAL / S/Nは14×12dot
- PRODUCT ID：上段ライン側へ6dot下寄せ
- 用紙検知：ギャップ紙（ZPL `^MNY`）
- 印刷方式：熱転写（ZPL `^MTT`）
- 外枠：なし
- 完品シール：製造シリアルQR、GLTEK G品番、製造シリアル
- 箱シール：G品番Code 128、製造シリアルQR、メーカー品番・純正品番・仕様
- 完了条件：プリンターのTCP受信口へZPL全体の送信が完了した時点

Brother公式のZPLエミュレーション利用条件に従い、プリンター本体の用紙種類・ギャップセンサー・45×20mm用紙は事前に校正してください。
