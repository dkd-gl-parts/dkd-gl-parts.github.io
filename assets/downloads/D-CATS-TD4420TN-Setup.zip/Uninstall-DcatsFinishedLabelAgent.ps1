[CmdletBinding()]
param(
    [switch]$RemoveEncryptedAuthentication,
    [string]$InstallRoot = (Join-Path $env:LOCALAPPDATA 'D-CATS\FinishedLabelAgent')
)

$ErrorActionPreference = 'Stop'
$taskName = 'D-CATS Finished Label Background Agent'
$statusTaskName = 'D-CATS Finished Label Status Server'
$protocolRoot = 'HKCU:\Software\Classes\dcats-label-printer'

foreach ($installedTaskName in @($taskName, $statusTaskName)) {
    $task = Get-ScheduledTask -TaskName $installedTaskName -ErrorAction SilentlyContinue
    if ($task) {
        Stop-ScheduledTask -TaskName $installedTaskName -ErrorAction SilentlyContinue
        Unregister-ScheduledTask -TaskName $installedTaskName -Confirm:$false
    }
}

if (Test-Path -LiteralPath $protocolRoot) {
    Remove-Item -LiteralPath $protocolRoot -Recurse -Force
}

if ($RemoveEncryptedAuthentication -and (Test-Path -LiteralPath $InstallRoot)) {
    $resolvedRoot = [IO.Path]::GetFullPath($InstallRoot)
    $allowedRoot = [IO.Path]::GetFullPath((Join-Path $env:LOCALAPPDATA 'D-CATS'))
    if (-not $resolvedRoot.StartsWith($allowedRoot + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)) {
        throw 'Refusing to remove a directory outside the D-CATS local application folder.'
    }
    Remove-Item -LiteralPath $resolvedRoot -Recurse -Force
}

Write-Output 'The D-CATS finished-label background task was removed.'
