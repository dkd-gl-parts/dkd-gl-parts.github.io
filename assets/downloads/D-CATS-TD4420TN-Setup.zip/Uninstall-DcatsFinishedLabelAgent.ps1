[CmdletBinding()]
param(
    [switch]$RemoveEncryptedAuthentication,
    [string]$InstallRoot = (Join-Path $env:LOCALAPPDATA 'D-CATS\FinishedLabelAgent')
)

$ErrorActionPreference = 'Stop'
$taskName = 'D-CATS Finished Label Background Agent'
$protocolRoot = 'HKCU:\Software\Classes\dcats-label-printer'

$task = Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue
if ($task) {
    Stop-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue
    Unregister-ScheduledTask -TaskName $taskName -Confirm:$false
}

if (Test-Path -LiteralPath $protocolRoot) {
    Remove-Item -LiteralPath $protocolRoot -Recurse -Force
}

if ($RemoveEncryptedAuthentication -and (Test-Path -LiteralPath $InstallRoot)) {
    $resolvedRoot = [IO.Path]::GetFullPath($InstallRoot)
    $allowedRoot = [IO.Path]::GetFullPath((Join-Path $env:LOCALAPPDATA 'D-CATS'))
    if (-not $resolvedRoot.StartsWith($allowedRoot + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)) {
        throw 'Refusing to remove a directory outside the D-CATS local application folder.'
    }
    Remove-Item -LiteralPath $resolvedRoot -Recurse -Force
}

Write-Output 'The D-CATS finished-label background task was removed.'
