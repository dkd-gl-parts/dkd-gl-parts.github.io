[CmdletBinding()]
param(
    [string]$InstallRoot = (Join-Path $env:LOCALAPPDATA 'D-CATS\FinishedLabelAgent')
)

$taskName = 'D-CATS Finished Label Background Agent'
$task = Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue
$taskInfo = if ($task) { Get-ScheduledTaskInfo -TaskName $taskName } else { $null }
$configPath = Join-Path $InstallRoot 'config.json'
$authPath = Join-Path $InstallRoot 'auth.dpapi'
$logPath = Join-Path $InstallRoot 'agent.log'
$lastLog = if (Test-Path -LiteralPath $logPath) { [string](Get-Content -LiteralPath $logPath -Tail 1 | Select-Object -Last 1) } else { '' }
$configuredPrinters = @()
$configurationVersion = $null
if (Test-Path -LiteralPath $configPath) {
    try {
        $config = [IO.File]::ReadAllText($configPath, [Text.Encoding]::UTF8) | ConvertFrom-Json
        $configurationVersion = [int]$config.version
        if ($config.printers) {
            $configuredPrinters = @($config.printers | ForEach-Object {
                [pscustomobject]@{
                    PrinterCode = [string]$_.printerCode
                    LabelTarget = [string]$_.labelTarget
                    LabelFormat = [string]$_.labelFormat
                    ProfileName = [string]$_.profileName
                    MediaWidthMm = [int]$_.mediaWidthMm
                    MediaHeightMm = [int]$_.mediaHeightMm
                    Dpi = [int]$_.dpi
                    PrinterName = [string]$_.printerName
                    PrinterAddress = [string]$_.printerAddress
                    PrinterPort = [int]$_.printerPort
                }
            })
        } elseif ($config.printerCode) {
            $configuredPrinters = @([pscustomobject]@{
                PrinterCode = [string]$config.printerCode
                LabelTarget = 'finished_product'
                PrinterName = [string]$config.printerName
                PrinterAddress = [string]$config.printerAddress
            })
        }
    } catch {}
}

[pscustomobject]@{
    Installed = [bool]$task
    TaskState = if ($task) { [string]$task.State } else { 'NotInstalled' }
    LastTaskResult = if ($taskInfo) { $taskInfo.LastTaskResult } else { $null }
    ConfigurationVersion = $configurationVersion
    ConfigurationPresent = Test-Path -LiteralPath $configPath
    EncryptedAuthenticationPresent = Test-Path -LiteralPath $authPath
    ConfiguredPrinters = $configuredPrinters
    LastLogEntry = $lastLog
}
