[CmdletBinding()]
param(
    [string]$InstallRoot = (Join-Path $env:LOCALAPPDATA 'D-CATS\FinishedLabelAgent'),
    [ValidateRange(1024, 65535)][int]$Port = 37643
)

$ErrorActionPreference = 'Stop'
$agentTaskName = 'D-CATS Finished Label Background Agent'
$configPath = Join-Path $InstallRoot 'config.json'
$authPath = Join-Path $InstallRoot 'auth.dpapi'
$allowedOrigins = @(
    'https://dcats.daiko-denki.co.jp',
    'https://dkd-gl-parts.github.io'
)

function Get-SafeAgentStatus {
    $agentTask = Get-ScheduledTask -TaskName $agentTaskName -ErrorAction SilentlyContinue
    $configurationVersion = 0
    $configuredTargets = @()
    $configurationValid = $false

    if (Test-Path -LiteralPath $configPath) {
        try {
            $config = [IO.File]::ReadAllText($configPath, [Text.Encoding]::UTF8) | ConvertFrom-Json
            $configurationVersion = [int]$config.version
            $configuredTargets = @($config.printers | Where-Object {
                $null -eq $_.enabled -or [bool]$_.enabled
            } | ForEach-Object {
                ([string]$_.labelTarget).Trim().ToLowerInvariant()
            } | Where-Object {
                $_ -in @('finished_product', 'box')
            } | Select-Object -Unique)
            $configurationValid = (
                [string]$config.supabaseProjectRef -eq 'jqoeqximtwfpqwzngutj' -and
                $configurationVersion -ge 4 -and
                'finished_product' -in $configuredTargets
            )
        } catch {
            $configurationValid = $false
        }
    }

    $authenticationPresent = (Test-Path -LiteralPath $authPath) -and (Get-Item -LiteralPath $authPath).Length -gt 0
    $agentRunning = [bool]$agentTask -and [string]$agentTask.State -eq 'Running'
    $setupComplete = [bool]$agentTask -and $configurationValid -and $authenticationPresent
    $state = if ($setupComplete -and $agentRunning) { 'configured' } else { 'attention' }

    return [ordered]@{
        schemaVersion = 1
        product = 'dcats-finished-label-agent'
        state = $state
        setupComplete = $setupComplete
        agentRunning = $agentRunning
        configurationVersion = $configurationVersion
        configuredTargets = @($configuredTargets)
        checkedAt = [DateTimeOffset]::UtcNow.ToString('o')
    }
}

function Write-HttpResponse {
    param(
        [Parameter(Mandatory = $true)][IO.Stream]$Stream,
        [Parameter(Mandatory = $true)][int]$StatusCode,
        [Parameter(Mandatory = $true)][string]$Reason,
        [string]$Body = '',
        [string]$Origin = '',
        [switch]$Preflight,
        [switch]$AllowPrivateNetwork
    )

    $bodyBytes = [Text.Encoding]::UTF8.GetBytes($Body)
    $headers = New-Object Collections.Generic.List[string]
    $headers.Add(('HTTP/1.1 {0} {1}' -f $StatusCode, $Reason))
    $headers.Add('Content-Type: application/json; charset=utf-8')
    $headers.Add('Cache-Control: no-store')
    $headers.Add('X-Content-Type-Options: nosniff')
    $headers.Add('Connection: close')
    if ($Origin) {
        $headers.Add('Access-Control-Allow-Origin: ' + $Origin)
        $headers.Add('Vary: Origin')
    }
    if ($Preflight) {
        $headers.Add('Access-Control-Allow-Methods: GET, OPTIONS')
        $headers.Add('Access-Control-Allow-Headers: Content-Type')
        $headers.Add('Access-Control-Max-Age: 600')
    }
    if ($AllowPrivateNetwork) {
        $headers.Add('Access-Control-Allow-Private-Network: true')
    }
    $headers.Add('Content-Length: ' + $bodyBytes.Length)
    $headerBytes = [Text.Encoding]::ASCII.GetBytes(($headers -join "`r`n") + "`r`n`r`n")
    try {
        $Stream.Write($headerBytes, 0, $headerBytes.Length)
        if ($bodyBytes.Length -gt 0) { $Stream.Write($bodyBytes, 0, $bodyBytes.Length) }
        $Stream.Flush()
    } finally {
        [Array]::Clear($headerBytes, 0, $headerBytes.Length)
        [Array]::Clear($bodyBytes, 0, $bodyBytes.Length)
    }
}

$listener = [Net.Sockets.TcpListener]::new([Net.IPAddress]::Loopback, $Port)
$listener.Start()
try {
    while ($true) {
        $client = $listener.AcceptTcpClient()
        $stream = $null
        $reader = $null
        try {
            $client.ReceiveTimeout = 2500
            $client.SendTimeout = 2500
            $stream = $client.GetStream()
            $stream.ReadTimeout = 2500
            $stream.WriteTimeout = 2500
            $reader = [IO.StreamReader]::new($stream, [Text.Encoding]::ASCII, $false, 1024, $true)
            $requestLine = $reader.ReadLine()
            if (-not $requestLine -or $requestLine.Length -gt 2048) {
                Write-HttpResponse -Stream $stream -StatusCode 400 -Reason 'Bad Request'
                continue
            }

            $headers = @{}
            for ($headerCount = 0; $headerCount -lt 64; $headerCount += 1) {
                $line = $reader.ReadLine()
                if ($null -eq $line -or $line -eq '') { break }
                if ($line.Length -gt 4096) { throw 'HTTP header is too long.' }
                $separator = $line.IndexOf(':')
                if ($separator -gt 0) {
                    $headers[$line.Substring(0, $separator).Trim().ToLowerInvariant()] = $line.Substring($separator + 1).Trim()
                }
            }

            $parts = @($requestLine.Split(' '))
            $method = if ($parts.Count -ge 1) { $parts[0].ToUpperInvariant() } else { '' }
            $path = if ($parts.Count -ge 2) { $parts[1] } else { '' }
            $requestHost = [string]$headers['host']
            $origin = [string]$headers['origin']
            $hostAllowed = $requestHost -in @("127.0.0.1:$Port", "localhost:$Port")
            $originAllowed = $origin -and $origin -in $allowedOrigins
            $privateNetworkRequested = [string]$headers['access-control-request-private-network'] -eq 'true'

            if (-not $hostAllowed -or -not $originAllowed) {
                Write-HttpResponse -Stream $stream -StatusCode 403 -Reason 'Forbidden'
                continue
            }
            if ($path -ne '/status') {
                Write-HttpResponse -Stream $stream -StatusCode 404 -Reason 'Not Found' -Origin $origin
                continue
            }
            if ($method -eq 'OPTIONS') {
                Write-HttpResponse -Stream $stream -StatusCode 204 -Reason 'No Content' -Origin $origin -Preflight -AllowPrivateNetwork:$privateNetworkRequested
                continue
            }
            if ($method -ne 'GET') {
                Write-HttpResponse -Stream $stream -StatusCode 405 -Reason 'Method Not Allowed' -Origin $origin
                continue
            }

            $body = Get-SafeAgentStatus | ConvertTo-Json -Depth 4 -Compress
            Write-HttpResponse -Stream $stream -StatusCode 200 -Reason 'OK' -Body $body -Origin $origin -AllowPrivateNetwork:$privateNetworkRequested
        } catch {
            if ($stream) {
                try { Write-HttpResponse -Stream $stream -StatusCode 500 -Reason 'Internal Server Error' } catch {}
            }
        } finally {
            if ($reader) { $reader.Dispose() }
            if ($stream) { $stream.Dispose() }
            $client.Dispose()
        }
    }
} finally {
    $listener.Stop()
}
