﻿[CmdletBinding()]
param(
    [Parameter(Position = 0)][string]$ActionUri = 'dcats-label-printer://setup',
    [string]$InstallRoot = (Join-Path $env:LOCALAPPDATA 'D-CATS\FinishedLabelAgent')
)

$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms

function Show-DcatsMessage {
    param(
        [string]$Message,
        [string]$Title = 'D-CATS 印刷端末',
        [Windows.Forms.MessageBoxIcon]$Icon = [Windows.Forms.MessageBoxIcon]::Information
    )
    [void][Windows.Forms.MessageBox]::Show(
        $Message,
        $Title,
        [Windows.Forms.MessageBoxButtons]::OK,
        $Icon
    )
}

try {
    $uri = [Uri]$ActionUri
    if ($uri.Scheme -ne 'dcats-label-printer') { throw 'Unsupported action scheme.' }
    $action = $uri.Host.ToLowerInvariant()
    $target = $uri.AbsolutePath.Trim('/').ToLowerInvariant()
    if ($target -notin @('', 'finished_product', 'box')) { throw 'Unsupported label target.' }

    if ($action -eq 'setup') {
        $setupPath = Join-Path $InstallRoot 'Start-DcatsFinishedLabelAgentSetup.ps1'
        if (-not (Test-Path -LiteralPath $setupPath)) {
            throw '設定ツールが見つかりません。D-CATS画面から初回設定パッケージをダウンロードしてください。'
        }
        Start-Process -FilePath 'powershell.exe' -ArgumentList @(
            '-NoProfile',
            '-ExecutionPolicy', 'Bypass',
            '-File', ('"{0}"' -f $setupPath)
        )
        exit 0
    }

    if ($action -eq 'status') {
        $statusPath = Join-Path $InstallRoot 'Get-DcatsFinishedLabelAgentStatus.ps1'
        if (-not (Test-Path -LiteralPath $statusPath)) { throw '状態確認ツールが見つかりません。' }
        $status = & $statusPath
        $printerLines = @($status.ConfiguredPrinters | ForEach-Object {
            '{0}: {1} ({2}:{3})' -f $_.ProfileName, $_.PrinterName, $_.PrinterAddress, $_.PrinterPort
        })
        Show-DcatsMessage -Message ((@(
            '状態: ' + [string]$status.TaskState,
            '設定バージョン: ' + [string]$status.ConfigurationVersion,
            ''
        ) + $printerLines + @('', '最終ログ: ' + [string]$status.LastLogEntry)) -join "`r`n")
        exit 0
    }

    if ($action -notin @('calibrate', 'test') -or -not $target) { throw 'Unsupported printer action.' }
    $targetName = if ($target -eq 'box') { '箱シール 80×60mm' } else { '完品シール 45×20mm' }
    if ($action -eq 'calibrate') {
        $answer = [Windows.Forms.MessageBox]::Show(
            ($targetName + "の用紙と熱転写リボンをセットし、ヘッドを閉じましたか？`r`n校正では空ラベルが数枚送られることがあります。"),
            'D-CATS センサー校正',
            [Windows.Forms.MessageBoxButtons]::YesNo,
            [Windows.Forms.MessageBoxIcon]::Question
        )
        if ($answer -ne [Windows.Forms.DialogResult]::Yes) { exit 0 }
        $calibratorPath = Join-Path $InstallRoot 'Calibrate-DcatsLabelPrinter.ps1'
        $result = & $calibratorPath -LabelTarget $target -ConfirmMediaLoaded
        Show-DcatsMessage -Message ($targetName + "の校正が完了しました。`r`n" + [string]($result | Select-Object -Last 1))
        exit 0
    }

    $testPath = Join-Path $InstallRoot 'Test-DcatsLabelPrinter.ps1'
    $testResult = & $testPath -LabelTarget $target
    Show-DcatsMessage -Message ($targetName + "へテストラベルを1枚送りました。`r`n" + [string]($testResult | Select-Object -Last 1))
} catch {
    $message = ($_.Exception.Message -replace '[\r\n]+', ' ').Trim()
    Show-DcatsMessage -Message $message -Title 'D-CATS 印刷端末エラー' -Icon ([Windows.Forms.MessageBoxIcon]::Error)
    exit 1
}
